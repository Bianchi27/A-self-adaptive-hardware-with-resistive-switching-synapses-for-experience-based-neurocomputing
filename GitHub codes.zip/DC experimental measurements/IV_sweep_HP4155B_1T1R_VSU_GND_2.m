%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% THIS MATLAB FUNCTION, IS RELATED TO THE HARDWARE MEASUREMENT SETUP IN THE
% PAPER "A SELF-ADAPTIVE HARDWARE WITH RESISTIVE SWITCHING SYNAPSES FOR 
% EXPERIENCE-BASED NEUROCOMPUTING" by Stefano Bianchi, Irene Munoz Martin
% et al.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [VTE,ITE,VBE,IBE] = IV_sweep_HP4155B_1T1R_VSU_GND_2(gpib_adr, chTE, chPG, chBE, chG,...
    si, sf, vPG,vBE, vG, Np, ...
    compTE, compPG, compBE, compG, VorI, td, NPLC, th, doub, lin, read)
%IV sample with HP4155B Parameter Analyzer
%VorI must be 'V' or 'I'
%lin must be LIN for linear sampling, L10, L25 or L50 to have 10, 25 or 50
%points per decade
%si = start
%sf = stop
%Np = number of step (only for 'LIN' mode)
%comp = Voltage/current compliance (depends on the choice of VorI)
%td = delay time
%th = hold time
%doub = 1 for up and down sweep, 0 for only ramp-up sweep
%ch is either 'SMU1' or 'SMU2' or 'SMU3' or 'SMU4' or 'VSU1'
%read = 1 if you want to read the data from instrument, 0 otherwise

t_dly = 1e-3; %10e-3;
g = gpib('ni', 0, gpib_adr);
%g = gpib('ni', 1, gpib_adr); %USB GPIB converter
g.InputBufferSize=1e6;
g.Timeout=1000;
fopen(g)
fprintf(g, '*RST;')
pause(t_dly)
fprintf(g, ':PAGE:CHAN:SMU1:DIS;')
pause(t_dly)
fprintf(g, ':PAGE:CHAN:SMU2:DIS;')
pause(t_dly)
fprintf(g, ':PAGE:CHAN:SMU3:DIS;')
pause(t_dly)
fprintf(g, ':PAGE:CHAN:SMU4:DIS;')
pause(t_dly)
fprintf(g, ':PAGE:CHAN:VMU1:DIS;')
pause(t_dly)
fprintf(g, ':PAGE:CHAN:VMU2:DIS;')
pause(t_dly)
fprintf(g, ':PAGE:CHAN:VSU1:DIS;')
pause(t_dly)
fprintf(g, ':PAGE:CHAN:VSU2:DIS;')
pause(t_dly)

pause(t_dly)
string = sprintf(':PAGE:CHAN:MODE SWEEP;');
fprintf(g, string)

%set force channel
pause(t_dly)
fprintf(g, 'PAGE:CHAN:%s:VNAM "Vdev";', chTE)
pause(t_dly)
fprintf(g, 'PAGE:CHAN:%s:INAM "Idev";', chTE)
pause(t_dly)
string = sprintf(':PAGE:CHAN:%s:MODE %s;', chTE,  VorI);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:CHAN:%s:FUNC VAR1;', chTE);
fprintf(g, string)

%set PG channel
fprintf(g, 'PAGE:CHAN:%s:VNAM "VPG";', chPG)
pause(t_dly)
fprintf(g, 'PAGE:CHAN:%s:INAM "IPG";', chPG)
pause(t_dly)
string = sprintf(':PAGE:CHAN:%s:MODE V;', chPG);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:CHAN:%s:FUNC CONS;', chPG);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:MEAS:CONS:%s %d;', chPG, vPG);
fprintf(g, string)
pause(t_dly)

%set BE channel
fprintf(g, 'PAGE:CHAN:%s:VNAM "VBE";', chBE)
pause(t_dly)
fprintf(g, 'PAGE:CHAN:%s:INAM "IBE";', chBE)
pause(t_dly)
string = sprintf(':PAGE:CHAN:%s:MODE V;', chBE);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:CHAN:%s:FUNC CONS;', chBE);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:MEAS:CONS:%s %d;', chBE, vBE);
fprintf(g, string)
pause(t_dly)

%set G channel
fprintf(g, 'PAGE:CHAN:%s:VNAM "VG";', chG)
pause(t_dly)
fprintf(g, 'PAGE:CHAN:%s:INAM "IG";', chG)
pause(t_dly)
string = sprintf(':PAGE:CHAN:%s:MODE V;', chG);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:CHAN:%s:FUNC CONS;', chG);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:MEAS:CONS:%s %d;', chG, vG);
fprintf(g, string)
pause(t_dly)

if doub == 1
    string = sprintf(':PAGE:MEAS:SWE:VAR1:MODE DOUB;');
    fprintf(g, string)
else
    string = sprintf(':PAGE:MEAS:SWE:VAR1:MODE SING;');
    fprintf(g, string)
end

pause(t_dly)


string = sprintf(':PAGE:MEAS;');
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:MEAS:VAR1:SPAC %s;', lin);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:MEAS:VAR1:STAR %d;', si);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:MEAS:VAR1:STOP %d;', sf);
fprintf(g, string)
pause(t_dly)
if strcmp(lin, 'LIN') == 1
    string = sprintf(':PAGE:MEAS:VAR1:STEP %0.1d;', (sf-si)/Np);
    fprintf(g, string)
    pause(t_dly)
end

string = sprintf(':PAGE:MEAS:SWE:VAR1:COMP %d;', compTE);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:MEAS:SWE:CONS:%s:COMP %d;', chPG,compPG);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:MEAS:SWE:CONS:%s:COMP %d;', chBE,compBE);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:MEAS:SWE:CONS:%s:COMP %d;', chG,compG);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:MEAS:HTIM %d;', th);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:MEAS:SWE:DEL %d;', td);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:MEAS:SAMP:FILT ON;');
fprintf(g, string )
pause(t_dly)

string = sprintf(':PAGE:MEAS:MSET;');
fprintf(g, string)
pause(t_dly)
%string = sprintf(':PAGE:MEAS:MSET:%s:RANG:MODE AUTO;', chTE);

string = sprintf(':PAGE:MEAS:MSET:%s:RANG:MODE LIMITED;', chTE);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:MEAS:MSET:%s:RANG 10e-12;', chTE);

fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:MEAS:MSET:%s:RANG %d;', chTE, 1e-9);
fprintf(g, string)
pause(t_dly)
%string = sprintf(':PAGE:MEAS:MSET:%s:RANG:MODE AUTO;', chG);
string = sprintf(':PAGE:MEAS:MSET:%s:RANG:MODE FIXED;', chPG);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:MEAS:MSET:%s:RANG %d;', chPG, compPG);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:MEAS:MSET:%s:RANG:MODE FIXED;', chG);
fprintf(g, string)
pause(t_dly)
string = sprintf(':PAGE:MEAS:MSET:%s:RANG %d;', chG, compG);
fprintf(g, string)
pause(t_dly)
% string = sprintf(':PAGE:MEAS:MSET:%s:RANG:MODE AUTO;', chBE);
% string = sprintf(':PAGE:MEAS:MSET:%s:RANG:MODE FIXED;', chBE);
string = sprintf(':PAGE:MEAS:MSET:%s:RANG:MODE LIMITED;', chBE);
fprintf(g, string)
pause(t_dly)
% string = sprintf(':PAGE:MEAS:MSET:%s:RANG %d;', chBE, compBE);
string = sprintf(':PAGE:MEAS:MSET:%s:RANG %d;', chBE, 1e-9);
fprintf(g, string)
pause(t_dly)

if NPLC>=2
    string = sprintf(':PAGE:MEAS:MSET:ITIM:MODE LONG;');
    fprintf(g, string )
    pause(t_dly)
    string = sprintf(':PAGE:MEAS:MSET:ITIM:LONG %d;', NPLC);
    fprintf(g, string )
    pause(t_dly)
elseif NPLC == 1
    string = sprintf(':PAGE:MEAS:MSET:ITIM:MODE MED;');
    fprintf(g, string )
    pause(t_dly)
    string = sprintf(':PAGE:MEAS:MSET:ITIM:MED %d;', NPLC);
    fprintf(g, string )
    pause(t_dly)
else
    string = sprintf(':PAGE:MEAS:MSET:ITIM:MODE SHOR;');
    fprintf(g, string )
    pause(t_dly)
    string = sprintf(':PAGE:MEAS:MSET:ITIM:SHOR %d;', NPLC);
    fprintf(g, string )
    pause(t_dly)
end

string = sprintf(':FORM:DATA ASC;');
fprintf(g, string )
pause(t_dly)
string = sprintf(':FORM:BORD NORM;');
fprintf(g, string )
pause(t_dly)
string = sprintf(':PAGE:DISP:MODE LIST;');
pause(t_dly)
fprintf(g, string )
string = sprintf(':PAGE:DISP:SET:LIST:SEL "Vdev","Idev","VBE","IBE";');
fprintf(g, string )
pause(t_dly)
string = sprintf(':PAGE:GLIS:GRAP:MENU;');
fprintf(g, string )
pause(t_dly)
if VorI=='V'
string = sprintf(':PAGE:DISP:GRAP:X:SCAL LIN;');
fprintf(g, string )
pause(t_dly)
% string = sprintf(':PAGE:DISP:GRAP:Y1:MIN 1e-13');
% fprintf(g, string )
% string = sprintf(':PAGE:DISP:GRAP:Y1:MAX 3e-5');
% fprintf(g, string )
string = sprintf(':PAGE:DISP:GRAP:Y1:SCAL LOG;');
fprintf(g, string )
pause(t_dly)
else
string = sprintf(':PAGE:DISP:GRAP:Y1:SCAL LIN;');
fprintf(g, string )
pause(t_dly)
string = sprintf(':PAGE:DISP:GRAP:X:SCAL LOG;');
fprintf(g, string )
pause(t_dly)  
end
string = sprintf(':PAGE:SCON:SING;');
fprintf(g, string )

if read == 1
    
    status=query(g, '*OPC?');
    while(strfind(status,'1')~=1)
%         fprintf('measuring\n')
        status=query(g, '*OPC?');
    end
%     pause(10)
%     if strcmp(lin, 'LIN')
%         %pause(Np*0.65)
%         pause(40)
%         %pause((Np+1)*NPLC*25e-3*3)
%     elseif strcmp(lin, 'L10')
% %         pause(150*log10(abs(sf/si))*25e-3*NPLC*(doub+1)/2)
%         pause(45)
%     elseif strcmp(lin, 'L25')
%         pause(270)
%     elseif strcmp(lin, 'L50')
%         pause(40)
%     end
    
    
    string = sprintf(':DATA? "Vdev";');
    fprintf(g, string )
    pause(t_dly)
    VTE = fscanf(g);
    VTE = str2num(VTE)';
    pause(t_dly)
    string = sprintf(':DATA? "Idev";');
    fprintf(g, string )
    pause(t_dly)
    ITE = fscanf(g);
    ITE = str2num(ITE)';
    
    string = sprintf(':DATA? "VBE";');
    fprintf(g, string )
    pause(t_dly)
    VBE = fscanf(g);
    VBE = str2num(VBE)';
    pause(t_dly)
    string = sprintf(':DATA? "IBE";');
    fprintf(g, string )
    pause(t_dly)
    IBE = fscanf(g);
    IBE = str2num(IBE)';
    
else
    VTE = NaN;
    ITE = NaN;
    VBE = NaN;
    IBE = NaN;
end

fclose(g)
delete(g)
clear g
return