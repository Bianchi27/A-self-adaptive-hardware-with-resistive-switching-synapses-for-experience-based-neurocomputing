%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% DEMONSTRATION OF AUTONOMOUS NAVIGATION BY EXPLOITING SYNAPTIC SCALING IN
% BIO-INPSIRED RECURRENT NEURAL NETWORKS: BEHAVIORAL CODE

% THIS CODE, IS A HIGH-LEVEL REPRESENTATION OF THE HARDWARE DESIGNED IN THE
% PAPER "A SELF-ADAPTIVE HARDWARE WITH RESISTIVE SWITCHING SYNAPSES FOR 
% EXPERIENCE-BASED NEUROCOMPUTING" by Stefano Bianchi, Irene Munoz Martin
% et al.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% THIS CODE HAS BEEN DEVELOPED USING ARBITRARY UNITS FOR THE RRAM DEVICES
% DUE TO NON-DISCLOSURE AGREEMENTS. IN ORDER TO HAVE THE DATA OF THE RRAM DEVICES,
% PLEASE CONTACT THE CORRESPONDING AUTHOR WITH REASONABLE REQUEST. 

% BEING A HIGH-LEVEL CODE, ALSO THE NEURONAL REPRESENTATION AND THE STDP
% ALGORITHMS ARE SIMPLIFIED. WE PROVIDE IN PARALLEL TO THIS CODE THE CODE
% FOR MODELLING THE HOMEOSTATIC STDP AND THE MODEL OF THE STDP USED TO OPTIMIZE THE
% IMPLEMENTED HARDWARE.

% NOTE THAT IN LINES 1610 - 1665 IT IS POSSIBLE TO CHANGE THE INITIAL
% CONDITIONS OF THE EXPLORATION TRIALS. NOTE ALSO THAT THIS CODE PROVIDES A
% GENERAL BEHAVIORAL CASE; DEPENDING ON THE SEVERAL ANALYSIS THAT ARE
% WANTED TO BE CARRIED OUT, A LITTLE TUNING IS NECESSARY: FOR INSTANCE, IN
% ORDER TO SEE THE WEIGHTED EVOLUTION OF THE MAZE ENVIRONMENT CONSIDERING
% THE ENVIRONMENTAL CHANGES IT IS NECESSARY TO OPPORTUNELY WEIGHT EACH
% TRIAL OF EXPLORATION, OR SIMPLY TARGETTING A DIFFERENT CASE STUDY, WHICH
% IS HERE A GENERAL CASE IN ORDER TO MAKE UNDERSTANDABLE THE OVERALL CODES.
% NOTE ALSO THAT THE COLOR BARS FOR THE COLOR MAPS HAVE BEEN CHOSEN
% ARBITRARILY: CHANGING THE COLOR BAR AXIS COULD HELP IN VISUALIZING
% DIFFERENT FEATURES OF THE NETWORK ITSELF.

% IN PARALLEL TO THIS CODE, WE ALSO PROVIDE THE MATLAB-BASED SCRIPT FOR THE
% MANAGEMENT OF THE PULSER AND THE OSCILLOSCOPE.

% WE PROVIDE HERE ONLY THE MAIN STARTING CODE: FOR RRAM-BASED
% ANALYSIS, STATISTICS, CHOICES OF THE HARDWARE, PLEASE ASK DIRECTLY TO THE
% CORRESPONDING AUTHOR OF THIS PAPER


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%close all
%clear all

%VARIABLES

Aux_Homeostasis  = zeros(30);
Aux_Passaggi     = zeros(30);
Altezza          = 30;
Larghezza        = 30;
time_trials      = 600; % TIME 
num_trials       = 120;
X                = 4;
Y                = 28;
X_old            = X;
Y_old            = Y;
V_TE             = 0.08; % ARBITRARY VALUE FOR THE READ VOLTAGE
Soglia_nominale  = 1e-5; % ARBITRARY VALUE FOR THE NOMINAL THRESHOLD OF EACH NEURON
LRS              = 10e3; % ARBITRARY VALUE FOR THE NOMINAL LRS
HRS              = 300e3;% ARBITRARY VALUE FOR THE NOMINAL HRS
Max_current      = (1/HRS)*V_TE;
Integrazione_N   = 0;
Integrazione_N_E = 0;
Integrazione_E   = 0;
Integrazione_S_E = 0;
Integrazione_S   = 0;
Integrazione_S_O = 0;
Integrazione_O   = 0;
Integrazione_N_O = 0;
Flag             = 0;
Posizioni_matr   = 3;
Step_Recorded    = time_trials;
Step_R           = 1;
Esci             = 0;
ausiliare        = 0;
t_xaux           = 0;
Auxil            = -101;
a_aux            = 0;
b_aux            = 0;
Counter_aux      = 0;
Flag_victory     = 0;

%ALLOCATIONS

Matrice_Labirinto     = xlsread('Labirinto_1.xls'); % READ THE MATRIX OF MAZE 1
Matrice_Labirinto_1   = Matrice_Labirinto;

Matrice_Labirinto_2   = xlsread('Labirinto_1_2.xls'); % READ THE MATRIX OF MAZE 2
Matrice_Labirinto_2_2 = Matrice_Labirinto_2;

Matrice_passaggi    = zeros(Altezza,Larghezza);
Neurone             = zeros(Altezza,Larghezza);
Matrice_sinapsi_N   = zeros(Altezza,Larghezza,2);
Matrice_sinapsi_N_E = zeros(Altezza,Larghezza,2);
Matrice_sinapsi_E   = zeros(Altezza,Larghezza,2);
Matrice_sinapsi_S_E = zeros(Altezza,Larghezza,2);
Matrice_sinapsi_S   = zeros(Altezza,Larghezza,2);
Matrice_sinapsi_S_O = zeros(Altezza,Larghezza,2);
Matrice_sinapsi_O   = zeros(Altezza,Larghezza,2);
Matrice_sinapsi_N_O = zeros(Altezza,Larghezza,2);
Soglia_Neuroni      = ones(Altezza,Larghezza).*Soglia_nominale; % FOR SEMPLICITY, WE INSERT VARIABILITY OF THE DEVICES ONLY IN THE SYNAPTIC ELEMENTS --> IN REALITY EVEN HERE WE HAVE VARIABILITY (NO IMPACT ON SIMULATIONS)
Aggiorna_soglia     = Soglia_Neuroni;
Dummy               = zeros(1,time_trials);
Dummy2              = ones(1,time_trials);
Matrice_movimenti   = ones(Altezza,Larghezza,num_trials)*(-50);
Matrice_Ricorda     = ones(Posizioni_matr,Step_Recorded);
Vettore_Migl        = 900*ones(1,num_trials);
Vettore_Movimenti   = zeros(num_trials,Larghezza*Altezza);
Magica              = 1:1:900; Magica = reshape(Magica,30,30);
Aux                 = zeros(30,30,num_trials);
Aux_time            = zeros(30*30,time_trials);
figure(1);image((Matrice_Labirinto),'CDataMapping','Scaled');caxis([-100 100]);colormap('autumn');set(gca,'dataaspectratio',[1 1 1]);ax = gca;ax.FontSize = 12;ax.LineWidth = 1.5;
figure(2);image((Matrice_Labirinto_2),'CDataMapping','Scaled');caxis([-100 100]);colormap('autumn');set(gca,'dataaspectratio',[1 1 1]);ax = gca;ax.FontSize = 12;ax.LineWidth = 1.5;

for xxx=1:1:Altezza
    for yyy=1:1:Larghezza
        
        if Matrice_Labirinto(xxx,yyy)==1000 % ARBITRARY VALUE
            Soglia_Neuroni(xxx,yyy)=0;
        end
        
        %PREPARE THE SYNAPTIC DEVICES FOLLWING A RANDOM PROGRAMMING IN
        %ORDER TO MIMIC THE VARIABILITY OF THE DEVICES 
        
        Dummy_1 = rand(1);
        Dummy_2 = rand(1);
        Dummy_3 = rand(1);
        Dummy_4 = rand(1);
        Dummy_5 = rand(1);
        Dummy_6 = rand(1);
        Dummy_7 = rand(1);
        Dummy_8 = rand(1);
        
        if Dummy_1 > 0.1
            Matrice_sinapsi_N(xxx,yyy,1) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
            Matrice_sinapsi_N(xxx,yyy,2) = 10.^-random('Uniform',log10(0.6*HRS),log10(1.3*HRS));
        else
            Matrice_sinapsi_N(xxx,yyy,1) = 10.^-random('Uniform',log10(0.6*HRS),log10(1.3*HRS));
            Matrice_sinapsi_N(xxx,yyy,2) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
        end
        if Dummy_2 > 0.1
            Matrice_sinapsi_N_E(xxx,yyy,1) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
            Matrice_sinapsi_N_E(xxx,yyy,2) = 10.^-random('Uniform',log10(0.6*HRS),log10(1.3*HRS));
        else
            Matrice_sinapsi_N_E(xxx,yyy,1) = 10.^-random('Uniform',log10(0.6*HRS),log10(1.3*HRS));
            Matrice_sinapsi_N_E(xxx,yyy,2) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
        end
        if Dummy_3 > 0.1
            Matrice_sinapsi_E(xxx,yyy,1) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
            Matrice_sinapsi_E(xxx,yyy,2) = 10.^-random('Uniform',log10(0.6*HRS),log10(1.3*HRS));
        else
            Matrice_sinapsi_E(xxx,yyy,1) = 10.^-random('Uniform',log10(0.6*HRS),log10(1.3*HRS));
            Matrice_sinapsi_E(xxx,yyy,2) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
        end
        if Dummy_4 > 0.1
            Matrice_sinapsi_S_E(xxx,yyy,1) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
            Matrice_sinapsi_S_E(xxx,yyy,2) = 10.^-random('Uniform',log10(0.6*HRS),log10(1.3*HRS));
        else
            Matrice_sinapsi_S_E(xxx,yyy,1) = 10.^-random('Uniform',log10(0.6*HRS),log10(1.3*HRS));
            Matrice_sinapsi_S_E(xxx,yyy,2) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
        end
        if Dummy_5 > 0.1
            Matrice_sinapsi_S(xxx,yyy,1) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
            Matrice_sinapsi_S(xxx,yyy,2) = 10.^-random('Uniform',log10(0.6*HRS),log10(1.3*HRS));
        else
            Matrice_sinapsi_S(xxx,yyy,1) = 10.^-random('Uniform',log10(0.6*HRS),log10(1.3*HRS));
            Matrice_sinapsi_S(xxx,yyy,2) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
        end
        if Dummy_6 > 0.1
            Matrice_sinapsi_S_O(xxx,yyy,1) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
            Matrice_sinapsi_S_O(xxx,yyy,2) = 10.^-random('Uniform',log10(0.6*HRS),log10(1.3*HRS));
        else
            Matrice_sinapsi_S_O(xxx,yyy,1) = 10.^-random('Uniform',log10(0.6*HRS),log10(1.3*HRS));
            Matrice_sinapsi_S_O(xxx,yyy,2) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
        end
        if Dummy_7 > 0.1
            Matrice_sinapsi_O(xxx,yyy,1) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
            Matrice_sinapsi_O(xxx,yyy,2) = 10.^-random('Uniform',log10(0.6*HRS),log10(1.3*HRS));
        else
            Matrice_sinapsi_O(xxx,yyy,1) = 10.^-random('Uniform',log10(0.6*HRS),log10(1.3*HRS));
            Matrice_sinapsi_O(xxx,yyy,2) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
        end
        if Dummy_8 > 0.1
            Matrice_sinapsi_N_O(xxx,yyy,1) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
            Matrice_sinapsi_N_O(xxx,yyy,2) = 10.^-random('Uniform',log10(0.6*HRS),log10(1.3*HRS));
        else
            Matrice_sinapsi_N_O(xxx,yyy,1) = 10.^-random('Uniform',log10(0.6*HRS),log10(1.3*HRS));
            Matrice_sinapsi_N_O(xxx,yyy,2) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
        end
        
    end
end

%DEFINE THE VARIABILITY OF THE ENVIRONMENT

for N = 1:1:num_trials
    
    if N == num_trials/3
        
        Matrice_Labirinto = Matrice_Labirinto_2;
        Auxil = -101;
        
    end
    
    if N == num_trials*(2/3)
        
        Matrice_Labirinto = Matrice_Labirinto_1;
        Auxil = -100;
        
    end
    
    %DEFINE THE BEHAVIOR IN TIME OF THE AGENT
    
    for t = 1:1:time_trials
        
        if Esci == 0
            
            %RECORD THE POSITION FOR PLOTTING PURPOSES ONLY
            
            Matrice_movimenti(X,Y,N) = Matrice_movimenti(X,Y,N)+10;
            Matrice_passaggi(X,Y) = Matrice_passaggi(X,Y)+1;
            
            Max_current = (1/HRS)*V_TE;
            
            %DESCRIBE THE INTEGRATION PHASE -- SEE HARDWARE REALIZATION OF
            %HOW IT HAS BEEN IMPLEMENTED
            
            Integrazione_N   = V_TE.*Matrice_sinapsi_N(X,Y,1)+Integrazione_N;
            Integrazione_N_E = V_TE.*Matrice_sinapsi_N_E(X,Y,1)+Integrazione_N_E;
            Integrazione_E   = V_TE.*Matrice_sinapsi_E(X,Y,1)+Integrazione_E;
            Integrazione_S_E = V_TE.*Matrice_sinapsi_S_E(X,Y,1)+Integrazione_S_E;
            Integrazione_S   = V_TE.*Matrice_sinapsi_S(X,Y,1)+Integrazione_S;
            Integrazione_S_O = V_TE.*Matrice_sinapsi_S_O(X,Y,1)+Integrazione_S_O;
            Integrazione_O   = V_TE.*Matrice_sinapsi_O(X,Y,1)+Integrazione_O;
            Integrazione_N_O = V_TE.*Matrice_sinapsi_N_O(X,Y,1)+Integrazione_N_O;
            
            %DESCRIBE WTA IDEALLY --> SEE HARDWARE FOR BETTER EXPLANATION
            
            if (Integrazione_N > Soglia_Neuroni(X-1,Y)) && (Integrazione_N > Max_current)
                Max_current = Integrazione_N;
                Flag = 1;
            end
            if (Integrazione_N_E > Soglia_Neuroni(X-1,Y+1)) && (Integrazione_N_E > Max_current)
                Max_current = Integrazione_N_E;
                Flag = 2;
            end
            if (Integrazione_E > Soglia_Neuroni(X,Y+1)) && (Integrazione_E > Max_current)
                Max_current = Integrazione_E;
                Flag = 3;
            end
            if (Integrazione_S_E > Soglia_Neuroni(X+1,Y+1)) && (Integrazione_S_E > Max_current)
                Max_current = Integrazione_S_E;
                Flag = 4;
            end
            if (Integrazione_S > Soglia_Neuroni(X+1,Y)) && (Integrazione_S > Max_current)
                Max_current = Integrazione_S;
                Flag = 5;
            end
            if (Integrazione_S_O > Soglia_Neuroni(X+1,Y-1)) && (Integrazione_S_O > Max_current)
                Max_current = Integrazione_S_O;
                Flag = 6;
            end
            if (Integrazione_O > Soglia_Neuroni(X,Y-1)) && (Integrazione_O > Max_current)
                Max_current = Integrazione_O;
                Flag = 7;
            end
            if (Integrazione_N_O > Soglia_Neuroni(X-1,Y-1)) && (Integrazione_N_O > Max_current)
                Max_current = Integrazione_N_O;
                Flag = 8;
            end
            
            % IN THE FOLLOWING WE PROVIDE A DESCRIPTION OF ONE OF THE MOVEMENT IN A DIRECTION 
            
            switch Flag
                
                case 1
                    
                    if Soglia_Neuroni(X,Y)~=0
                        
                        X_old=X;
                        Y_old=Y;
                        X=X-1;
                        Y=Y+0;
                        Matrice_sinapsi_N(X_old,Y_old,1) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
                        Matrice_sinapsi_N(X_old,Y_old,2) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
                        
                        % WE MODEL THE PASSAGE ABOVE A POSITION BY THE
                        % HOMEOSTATIC THRESHOLD INCREASE DUE TO THE SPIKING
                        % ACTIVITY -- NOTE: ARBITRARY VALUE FOR THE MODEL
                        
                        Soglia_Neuroni(X_old,Y_old) = 3*Soglia_nominale;
                        
                        if Matrice_Labirinto(X,Y) == -100
                            
                            % WE MODEL NOW THE EFFECT OF THE PENALTY
                            % NOTE: ARBITRARY VALUES FOR NDA AGREEMENTS
                            
                            %STDP DEPRESSION IS IMPLEMENTED IN THE HARDWARE
                            %BUT IT IS NOT STRICTLY NECESSARY BY A BEHAVIORAL
                            %POINT OF VIEW
%                             Matrice_sinapsi_S_E(X_old,Y_old,1) = 10.^-random('Uniform',log10(0.9*HRS),log10(1.1*HRS));
%                             Matrice_sinapsi_S_E(X_old,Y_old,2) = 10.^-random('Uniform',log10(0.9*HRS),log10(1.1*HRS));
                            
                            Soglia_Neuroni(X,Y) = 10*Soglia_nominale;
                            Aggiorna_soglia(X,Y) = 10*Soglia_nominale;
                            
                            %NOTE THAT WE HAVE ALSO TO DEFINE THE
                            %BOUNDARIES TO MAKE THE CODE WORKING: IN THE
                            %HARDWARE REALIZATION IS THE MASTER OF THE
                            %SYSTEM WHICH MANAGES STRAIGHTFORWARD THIS POINT
                            
                            if X_old == Altezza-1 || Y_old == Larghezza-1 || X_old == 2 || Y_old ==2
                                Matrice_Labirinto(X_old,Y_old) = -100;
                                %ARBITRARY UNIT CHOSEN TO DETERMINE THE WALL
                            end
                            if X_old == Altezza-2 || Y_old == Larghezza-2 || X_old == 3
                                Matrice_Labirinto(X_old,Y_old) = -100;
                            end
                            X = X_old;
                            Y = Y_old;
                        end
                        
                        % REWARD: REMEMBER THE LAST WALKED POSITIONS
                        
                        % THE GRADE OF THE COMPLEXITY AND KNOWLDEGE OF THE
                        % ENVIRONMENT CAN BE HERE CHANGED ACCORDINGLY TO
                        % THE TEST CASE
                        
                        Matrice_Ricorda(1,Step_R)= X;
                        Matrice_Ricorda(2,Step_R)= Y;
                        Matrice_Ricorda(3,Step_R)= t;
                        
                        Step_R = Step_R +1;
                        
                        if Step_R > Step_Recorded
                            Step_R = 1;
                        end
                        
                        % NOTE THAT WE HAVE SET AN ARBITRARY VALUE OF THE
                        % GOAL OF THE MAZE FOR THE AUTONOMOUS NAVIGATION
                        
                        if Matrice_Labirinto(X,Y) == 1000
                            Vettore_Migl(1,N) = t;
                            for dfg = (Step_R-50):1:Step_R
                                if Step_R > 50
                                    Aggiorna_soglia(Matrice_Ricorda(1,dfg),Matrice_Ricorda(2,dfg)) = 0;
                                    Esci = 1;
                                end
                            end
                        end
                        
                        %IF THE NEURON HAS FIRED, ACCORDING TO SPIKE-TOMING-DEPENDENT PLASTICITY (STDP), YOU
                        %HAVE TO DISCHARGE THE INTEGRATION VARIABLE
                        
                        Integrazione_N   = 0*Integrazione_N;
                        Integrazione_N_E = 0*Integrazione_N_E;
                        Integrazione_E   = 0*Integrazione_E;
                        Integrazione_S_E = 0*Integrazione_S_E;
                        Integrazione_S   = 0*Integrazione_S;
                        Integrazione_S_O = 0*Integrazione_S_O;
                        Integrazione_O   = 0*Integrazione_O;
                        Integrazione_N_O = 0*Integrazione_N_O;
                        
                    else
                        
                        %IN THE FOLLOWING LINES, WE MODEL THE BURST-LIKE
                        %BEHAVIOR OF THE HOMEOSTATIC STDP CIRCUIT DESCRIBED
                        %IN THE PAPER: SUBSTANTIALLY, THE SYSTEM
                        %EXPERIENCES FAST INTEGRATE&FIRES ACTION OF THE
                        %NEURONS IN THOSE POSITION THAT HAD PREVIOUSLY
                        %RECEIVED A REWARD SINCE THE INTERNAL THRESHOLD IS
                        %LOWER THAN THE POST-SYNAPTIC CURRENT
                        
                        while Matrice_Labirinto(X,Y)~= 1000
                            Vettore_Migl(1,N) = t;
                            Counter_aux = Counter_aux +1;
                            if Matrice_passaggi(X,Y) < 100
                                Matrice_passaggi(X,Y) = Matrice_passaggi(X,Y)+1;
                            end
                            
                            % LOOK FOR POSITIONS THAT HAD PREVIOUSLY
                            % RECEIVED THE REWARD
                            
                            a_aux = randi([-1 1]);
                            b_aux = randi([-1 1]);
                            
                            if X+a_aux > 0 && X+a_aux <= Altezza
                                if Y+b_aux > 0 && Y+b_aux <= Larghezza
                                    if Soglia_Neuroni(X+a_aux,Y+b_aux) == 0
                                        X = X+a_aux;
                                        Y = Y+b_aux;
                                        if Matrice_Labirinto(X,Y) == 1000
                                            Flag_victory = 1;
                                        end
                                        Matrice_movimenti(X,Y,N) = Matrice_movimenti(X,Y,N)+1;
                                        Counter_aux = 0;
                                    end
                                    
                                    % ALWAYS USING ARBITRARY UNITS, WE NOW
                                    % DESCRIBE THE BEHAVIOR OF THOSE
                                    % RRAM STATE DEVICES WHICH EXPERIENCE A
                                    % PROGRAMMING HISTORY WHICH INDUCE A
                                    % DIFFERENT STATE CONDITION 
                                    
                                    if Matrice_Labirinto(X,Y) == -100 && Soglia_Neuroni(X,Y) == 0
                                        X = X-a_aux;
                                        Y = Y-b_aux;
                                        
                                        %THE FOLLWOING LINES COULD BE
                                        %OPTIMIZED BY A PURE SOFTWARE POINT
                                        %OF VIEW, BUT THEY HAVE BEEN USEFUL
                                        %FOR SIMULATE PARTICULAR CONDITIONS
                                        %OF THE HARDWARE RELATED TO THE
                                        %PROGRAMMING HISTORY OF THE
                                        %DEVICES: A VALUE OF 0.8 IS HERE CHOSEN
                                        %ARBITRARILY AND IT IS REALTED TO
                                        %THE USED RRAM DEVICES
                                        
                                        for xcx =1:1:12
                                            for ycy =1:1:Larghezza
                                                if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                                    Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                                    Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                                end
                                            end
                                        end
                                        for xcx =1:1:20
                                            for ycy =15:1:Larghezza
                                                if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                                    Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                                    Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                                end
                                            end
                                        end
                                        Counter_aux = 0;
                                        break;
                                    end
                                end
                            end
                            
                            %FURTHER MEASUREMENT-BASED CONDITIONS CAN BE ALSO IMPLEMENTED IN ORDER
                            %TO CREATE A MORE ACCURATE BEHAVIORAL MODEL OF
                            %THE AGENT
                            
                            if Counter_aux > 50 && X+a_aux > 0 && X+a_aux <= Altezza && Y+b_aux > 0 && Y+b_aux <= Larghezza
                                if Matrice_Labirinto(X+a_aux,Y+b_aux) ~= -100
                                    X = X+a_aux;
                                    Y = Y+b_aux;
                                end
                                Soglia_Neuroni(X,Y)  = 0.8*Soglia_nominale;
                                Aggiorna_soglia(X,Y) = 0.8*Soglia_nominale;
                                for xcx =1:1:12
                                    for ycy =1:1:Larghezza
                                        if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                            Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                            Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                        end
                                    end
                                end
                                for xcx =1:1:20
                                    for ycy =15:1:Larghezza
                                        if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                            Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                            Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                        end
                                    end
                                end                                
                                Matrice_movimenti(X,Y,N) = Matrice_movimenti(X,Y,N)+1;
                                Counter_aux = 0;
                                break;
                            end
                        end
                        if Flag_victory == 1
                            for dfg = (Step_R-4):1:Step_R
                                if Step_R > 10 % INCREMENTAL REWARD CONDITION
                                    Aggiorna_soglia(Matrice_Ricorda(1,dfg),Matrice_Ricorda(2,dfg)) = 0;
                                    Esci = 1;
                                end
                            end
                        end
                    end
                    
                case 2
                    
                    if Soglia_Neuroni(X,Y)~=0
                        
                        X_old=X;
                        Y_old=Y;
                        X=X-1;
                        Y=Y+1;
                        
                        Matrice_sinapsi_N_E(X_old,Y_old,1) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
                        Matrice_sinapsi_N_E(X_old,Y_old,2) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
                        Soglia_Neuroni(X_old,Y_old) = 3*Soglia_nominale;
                        
                        if Matrice_Labirinto(X,Y) == -100
                            Soglia_Neuroni(X,Y) = 10*Soglia_nominale;
                            Aggiorna_soglia(X,Y) = 10*Soglia_nominale;
                            %STDP DEPRESSION IS IMPLEMENTED IN THE HARDWARE
                            %BUT IT IS NOT STRICTLY NECESSARY BY BEHAVIORAL
                            %POINT OF VIEW
%                             Matrice_sinapsi_S_E(X_old,Y_old,1) = 10.^-random('Uniform',log10(0.9*HRS),log10(1.1*HRS));
%                             Matrice_sinapsi_S_E(X_old,Y_old,2) = 10.^-random('Uniform',log10(0.9*HRS),log10(1.1*HRS));
                            if X_old == Altezza-1 || Y_old == Larghezza-1 || X_old == 2 || Y_old ==2
                                Matrice_Labirinto(X_old,Y_old) = -100;
                            end
                            if X_old == Altezza-2 || Y_old == Larghezza-2 || X_old == 3
                                Matrice_Labirinto(X_old,Y_old) = -100;
                            end
                            X = X_old;
                            Y = Y_old;
                        end
                        
                        Matrice_Ricorda(1,Step_R)= X;
                        Matrice_Ricorda(2,Step_R)= Y;
                        Matrice_Ricorda(3,Step_R)= t;
                        
                        Step_R = Step_R +1;
                        
                        if Step_R > Step_Recorded
                            Step_R = 1;
                        end
                        
                        
                        if Matrice_Labirinto(X,Y) == 1000
                            Vettore_Migl(1,N) = t;
                            for dfg = (Step_R-50):1:Step_R
                                if Step_R > 50
                                    Aggiorna_soglia(Matrice_Ricorda(1,dfg),Matrice_Ricorda(2,dfg)) = 0;
                                    Esci = 1;
                                end
                            end
                        end
                        
                        Integrazione_N   = 0*Integrazione_N;
                        Integrazione_N_E = 0*Integrazione_N_E;
                        Integrazione_E   = 0*Integrazione_E;
                        Integrazione_S_E = 0*Integrazione_S_E;
                        Integrazione_S   = 0*Integrazione_S;
                        Integrazione_S_O = 0*Integrazione_S_O;
                        Integrazione_O   = 0*Integrazione_O;
                        Integrazione_N_O = 0*Integrazione_N_O;
                        
                    else
                        
                        while Matrice_Labirinto(X,Y)~= 1000
                            Vettore_Migl(1,N) = t;
                            Counter_aux = Counter_aux +1;
                            if Matrice_passaggi(X,Y) < 100
                                Matrice_passaggi(X,Y) = Matrice_passaggi(X,Y)+1;
                            end
                      
                            a_aux = randi([-1 1]);
                            b_aux = randi([-1 1]);
                            
                            if X+a_aux > 0 && X+a_aux <= Altezza
                                if Y+b_aux > 0 && Y+b_aux <= Larghezza
                                    if Soglia_Neuroni(X+a_aux,Y+b_aux) == 0
                                        X = X+a_aux;
                                        Y = Y+b_aux;
                                        if Matrice_Labirinto(X,Y) == 1000
                                            Flag_victory = 1;
                                        end
                                        Matrice_movimenti(X,Y,N) = Matrice_movimenti(X,Y,N)+1;
                                        Counter_aux = 0;
                                    end
                                    
                                    
                                    
                                    if Matrice_Labirinto(X,Y) == -100 && Soglia_Neuroni(X,Y) == 0
                                        X = X-a_aux;
                                        Y = Y-b_aux;
                                        for xcx =1:1:12
                                            for ycy =1:1:Larghezza
                                                if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                                    Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                                    Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                                end
                                            end
                                        end
                                        for xcx =1:1:20
                                            for ycy =15:1:Larghezza
                                                if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                                    Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                                    Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                                end
                                            end
                                        end
                                        Counter_aux = 0;
                                        break;
                                    end
                                end
                            end
                            if Counter_aux > 50 && X+a_aux > 0 && X+a_aux <= Altezza && Y+b_aux > 0 && Y+b_aux <= Larghezza
                                if Matrice_Labirinto(X+a_aux,Y+b_aux) ~= -100
                                    X = X+a_aux;
                                    Y = Y+b_aux;
                                end
                                Soglia_Neuroni(X,Y)  = 0.8*Soglia_nominale;
                                Aggiorna_soglia(X,Y) = 0.8*Soglia_nominale;
                                for xcx =1:1:12
                                    for ycy =1:1:Larghezza
                                        if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                            Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                            Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                        end
                                    end
                                end
                                for xcx =1:1:20
                                    for ycy =15:1:Larghezza
                                        if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                            Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                            Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                        end
                                    end
                                end                                
                                Matrice_movimenti(X,Y,N) = Matrice_movimenti(X,Y,N)+1;
                                Counter_aux = 0;
                                break;
                            end
                        end
                        if Flag_victory == 1
                            for dfg = (Step_R-4):1:Step_R
                                if Step_R > 10
                                    Aggiorna_soglia(Matrice_Ricorda(1,dfg),Matrice_Ricorda(2,dfg)) = 0;
                                    Esci = 1;
                                end
                            end
                        end
                    end
                    
                case 3
                    
                    if Soglia_Neuroni(X,Y)~=0
                        
                        X_old=X;
                        Y_old=Y;
                        X=X+0;
                        Y=Y+1;
                        
                        Matrice_sinapsi_E(X_old,Y_old,1) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
                        Matrice_sinapsi_E(X_old,Y_old,2) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
                        Soglia_Neuroni(X_old,Y_old) = 3*Soglia_nominale;
                        
                        if Matrice_Labirinto(X,Y) == -100
                            Soglia_Neuroni(X,Y) = 10*Soglia_nominale;
                            Aggiorna_soglia(X,Y) = 10*Soglia_nominale;
                            if X_old == Altezza-1 || Y_old == Larghezza-1 || X_old == 2 || Y_old ==2
                                Matrice_Labirinto(X_old,Y_old) = -100;
                            end
                            if X_old == Altezza-2 || Y_old == Larghezza-2 || X_old == 3
                                Matrice_Labirinto(X_old,Y_old) = -100;
                            end
                            X = X_old;
                            Y = Y_old;
                        end
                        
                        Matrice_Ricorda(1,Step_R)= X;
                        Matrice_Ricorda(2,Step_R)= Y;
                        Matrice_Ricorda(3,Step_R)= t;
                        
                        Step_R = Step_R +1;
                        
                        if Step_R > Step_Recorded
                            Step_R = 1;
                        end
                        
                        
                        if Matrice_Labirinto(X,Y) == 1000
                            Vettore_Migl(1,N) = t;
                            for dfg = (Step_R-50):1:Step_R
                                if Step_R > 50
                                    Aggiorna_soglia(Matrice_Ricorda(1,dfg),Matrice_Ricorda(2,dfg)) = 0;
                                    Esci = 1;
                                end
                            end
                        end
                        
                        Integrazione_N   = 0*Integrazione_N;
                        Integrazione_N_E = 0*Integrazione_N_E;
                        Integrazione_E   = 0*Integrazione_E;
                        Integrazione_S_E = 0*Integrazione_S_E;
                        Integrazione_S   = 0*Integrazione_S;
                        Integrazione_S_O = 0*Integrazione_S_O;
                        Integrazione_O   = 0*Integrazione_O;
                        Integrazione_N_O = 0*Integrazione_N_O;
                        
                    else
                        
                        while Matrice_Labirinto(X,Y)~= 1000
                            Vettore_Migl(1,N) = t;
                            Counter_aux = Counter_aux +1;
                            if Matrice_passaggi(X,Y) < 100
                                Matrice_passaggi(X,Y) = Matrice_passaggi(X,Y)+1;
                            end
                      
                            a_aux = randi([-1 1]);
                            b_aux = randi([-1 1]);
                            
                            if X+a_aux > 0 && X+a_aux <= Altezza
                                if Y+b_aux > 0 && Y+b_aux <= Larghezza
                                    if Soglia_Neuroni(X+a_aux,Y+b_aux) == 0
                                        X = X+a_aux;
                                        Y = Y+b_aux;
                                        if Matrice_Labirinto(X,Y) == 1000
                                            Flag_victory = 1;
                                        end
                                        Matrice_movimenti(X,Y,N) = Matrice_movimenti(X,Y,N)+1;
                                        Counter_aux = 0;
                                    end
                                    
                                    
                                    
                                    if Matrice_Labirinto(X,Y) == -100 && Soglia_Neuroni(X,Y) == 0
                                        X = X-a_aux;
                                        Y = Y-b_aux;
                                        for xcx =1:1:12
                                            for ycy =1:1:Larghezza
                                                if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                                    Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                                    Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                                end
                                            end
                                        end
                                        for xcx =1:1:20
                                            for ycy =15:1:Larghezza
                                                if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                                    Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                                    Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                                end
                                            end
                                        end
                                        Counter_aux = 0;
                                        break;
                                    end
                                end
                            end
                            if Counter_aux > 50 && X+a_aux > 0 && X+a_aux <= Altezza && Y+b_aux > 0 && Y+b_aux <= Larghezza
                                if Matrice_Labirinto(X+a_aux,Y+b_aux) ~= -100
                                    X = X+a_aux;
                                    Y = Y+b_aux;
                                end
                                Soglia_Neuroni(X,Y)  = 0.8*Soglia_nominale;
                                Aggiorna_soglia(X,Y) = 0.8*Soglia_nominale;
                                for xcx =1:1:12
                                    for ycy =1:1:Larghezza
                                        if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                            Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                            Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                        end
                                    end
                                end
                                for xcx =1:1:20
                                    for ycy =15:1:Larghezza
                                        if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                            Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                            Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                        end
                                    end
                                end                                
                                Matrice_movimenti(X,Y,N) = Matrice_movimenti(X,Y,N)+1;
                                Counter_aux = 0;
                                break;
                            end
                        end
                        if Flag_victory == 1
                            for dfg = (Step_R-4):1:Step_R
                                if Step_R > 10
                                    Aggiorna_soglia(Matrice_Ricorda(1,dfg),Matrice_Ricorda(2,dfg)) = 0;
                                    Esci = 1;
                                end
                            end
                        end
                    end
                    
                case 4
                    
                    if Soglia_Neuroni(X,Y)~=0
                        
                        X_old=X;
                        Y_old=Y;
                        X=X+1;
                        Y=Y+1;
                        
                        Matrice_sinapsi_S_E(X_old,Y_old,1) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
                        Matrice_sinapsi_S_E(X_old,Y_old,2) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
                        Soglia_Neuroni(X_old,Y_old) = 3*Soglia_nominale;
                        
                        if Matrice_Labirinto(X,Y) == -100
                            %STDP DEPRESSION IS IMPLEMENTED IN THE HARDWARE
                            %BUT IT IS NOT STRICTLY NECESSARY BY BEHAVIORAL
                            %POINT OF VIEW
%                             Matrice_sinapsi_S_E(X_old,Y_old,1) = 10.^-random('Uniform',log10(0.9*HRS),log10(1.1*HRS));
%                             Matrice_sinapsi_S_E(X_old,Y_old,2) = 10.^-random('Uniform',log10(0.9*HRS),log10(1.1*HRS));
                            Soglia_Neuroni(X,Y) = 10*Soglia_nominale;
                            Aggiorna_soglia(X,Y) = 10*Soglia_nominale;
                            if X_old == Altezza-1 || Y_old == Larghezza-1 || X_old == 2 || Y_old ==2
                                Matrice_Labirinto(X_old,Y_old) = -100;
                            end
                            if X_old == Altezza-2 || Y_old == Larghezza-2 || X_old == 3
                                Matrice_Labirinto(X_old,Y_old) = -100;
                            end
                            X = X_old;
                            Y = Y_old;
                        end
                        
                        Matrice_Ricorda(1,Step_R)= X;
                        Matrice_Ricorda(2,Step_R)= Y;
                        Matrice_Ricorda(3,Step_R)= t;
                        
                        Step_R = Step_R +1;
                        
                        if Step_R > Step_Recorded
                            Step_R = 1;
                        end
                        
                        
                        if Matrice_Labirinto(X,Y) == 1000
                            Vettore_Migl(1,N) = t;
                            for dfg = (Step_R-50):1:Step_R
                                if Step_R > 50
                                    Aggiorna_soglia(Matrice_Ricorda(1,dfg),Matrice_Ricorda(2,dfg)) = 0;
                                    Esci = 1;
                                end
                            end
                        end
                        
                        Integrazione_N   = 0*Integrazione_N;
                        Integrazione_N_E = 0*Integrazione_N_E;
                        Integrazione_E   = 0*Integrazione_E;
                        Integrazione_S_E = 0*Integrazione_S_E;
                        Integrazione_S   = 0*Integrazione_S;
                        Integrazione_S_O = 0*Integrazione_S_O;
                        Integrazione_O   = 0*Integrazione_O;
                        Integrazione_N_O = 0*Integrazione_N_O;
                        
                    else
                        
                        while Matrice_Labirinto(X,Y)~= 1000
                            Vettore_Migl(1,N) = t;
                            Counter_aux = Counter_aux +1;
                            if Matrice_passaggi(X,Y) < 100
                                Matrice_passaggi(X,Y) = Matrice_passaggi(X,Y)+1;
                            end
                      
                            a_aux = randi([-1 1]);
                            b_aux = randi([-1 1]);
                            
                            if X+a_aux > 0 && X+a_aux <= Altezza
                                if Y+b_aux > 0 && Y+b_aux <= Larghezza
                                    if Soglia_Neuroni(X+a_aux,Y+b_aux) == 0
                                        X = X+a_aux;
                                        Y = Y+b_aux;
                                        if Matrice_Labirinto(X,Y) == 1000
                                            Flag_victory = 1;
                                        end
                                        Matrice_movimenti(X,Y,N) = Matrice_movimenti(X,Y,N)+1;
                                        Counter_aux = 0;
                                    end
                                    
                                    % THE FOLLOWING LINES HAVE NOT
                                    % BIO-INSPIRED MEANING: THEY ONLY
                                    % REPRODUCE THE BURST FIRING ACTIVITY
                                    % OF THE HARDWARE AROUND THE
                                    % CHANGING MAZE POSITIONS
                                    
                                    if Matrice_Labirinto(X,Y) == -100 && Soglia_Neuroni(X,Y) == 0
                                        X = X-a_aux;
                                        Y = Y-b_aux;
                                        for xcx =1:1:12
                                            for ycy =1:1:Larghezza
                                                if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                                    Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                                    Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                                end
                                            end
                                        end
                                        for xcx =1:1:20
                                            for ycy =15:1:Larghezza
                                                if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                                    Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                                    Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                                end
                                            end
                                        end
                                        Counter_aux = 0;
                                        break;
                                    end
                                end
                            end
                            if Counter_aux > 50 && X+a_aux > 0 && X+a_aux <= Altezza && Y+b_aux > 0 && Y+b_aux <= Larghezza
                                if Matrice_Labirinto(X+a_aux,Y+b_aux) ~= -100
                                    X = X+a_aux;
                                    Y = Y+b_aux;
                                end
                                Soglia_Neuroni(X,Y)  = 0.8*Soglia_nominale;
                                Aggiorna_soglia(X,Y) = 0.8*Soglia_nominale;
                                for xcx =1:1:12
                                    for ycy =1:1:Larghezza
                                        if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                            Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                            Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                        end
                                    end
                                end
                                for xcx =1:1:20
                                    for ycy =15:1:Larghezza
                                        if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                            Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                            Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                        end
                                    end
                                end                                
                                Matrice_movimenti(X,Y,N) = Matrice_movimenti(X,Y,N)+1;
                                Counter_aux = 0;
                                break;
                            end
                        end
                        if Flag_victory == 1
                            for dfg = (Step_R-4):1:Step_R
                                if Step_R > 10
                                    Aggiorna_soglia(Matrice_Ricorda(1,dfg),Matrice_Ricorda(2,dfg)) = 0;
                                    Esci = 1;
                                end
                            end
                        end
                    end
                    
                case 5
                    
                    if Soglia_Neuroni(X,Y)~=0
                        
                        X_old=X;
                        Y_old=Y;
                        X=X+1;
                        Y=Y+0;
                        
                        Matrice_sinapsi_S(X_old,Y_old,1) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
                        Matrice_sinapsi_S(X_old,Y_old,2) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
                        Soglia_Neuroni(X_old,Y_old) = 3*Soglia_nominale;
                        
                        if Matrice_Labirinto(X,Y) == -100
%                             Matrice_sinapsi_S(X_old,Y_old,1) = 10.^-random('Uniform',log10(0.9*HRS),log10(1.1*HRS));
%                             Matrice_sinapsi_S(X_old,Y_old,2) = 10.^-random('Uniform',log10(0.9*HRS),log10(1.1*HRS));
                            Soglia_Neuroni(X,Y) = 10*Soglia_nominale;
                            Aggiorna_soglia(X,Y) = 10*Soglia_nominale;
                            if X_old == Altezza-1 || Y_old == Larghezza-1 || X_old == 2 || Y_old ==2
                                Matrice_Labirinto(X_old,Y_old) = -100;
                            end
                            if X_old == Altezza-2 || Y_old == Larghezza-2 || X_old == 3
                                Matrice_Labirinto(X_old,Y_old) = -100;
                            end
                            X = X_old;
                            Y = Y_old;
                        end
                        
                        Matrice_Ricorda(1,Step_R)= X;
                        Matrice_Ricorda(2,Step_R)= Y;
                        Matrice_Ricorda(3,Step_R)= t;
                        
                        Step_R = Step_R +1;
                        
                        if Step_R > Step_Recorded
                            Step_R = 1;
                        end
                        
                        
                        if Matrice_Labirinto(X,Y) == 1000
                            Vettore_Migl(1,N) = t;
                            for dfg = (Step_R-50):1:Step_R
                                if Step_R > 50
                                    Aggiorna_soglia(Matrice_Ricorda(1,dfg),Matrice_Ricorda(2,dfg)) = 0;
                                    Esci = 1;
                                end
                            end
                        end
                        
                        Integrazione_N   = 0*Integrazione_N;
                        Integrazione_N_E = 0*Integrazione_N_E;
                        Integrazione_E   = 0*Integrazione_E;
                        Integrazione_S_E = 0*Integrazione_S_E;
                        Integrazione_S   = 0*Integrazione_S;
                        Integrazione_S_O = 0*Integrazione_S_O;
                        Integrazione_O   = 0*Integrazione_O;
                        Integrazione_N_O = 0*Integrazione_N_O;
                        
                    else
                        
                        while Matrice_Labirinto(X,Y)~= 1000
                            Vettore_Migl(1,N) = t;
                            Counter_aux = Counter_aux +1;
                            if Matrice_passaggi(X,Y) < 100
                                Matrice_passaggi(X,Y) = Matrice_passaggi(X,Y)+1;
                            end
                      
                            a_aux = randi([-1 1]);
                            b_aux = randi([-1 1]);
                            
                            if X+a_aux > 0 && X+a_aux <= Altezza
                                if Y+b_aux > 0 && Y+b_aux <= Larghezza
                                    if Soglia_Neuroni(X+a_aux,Y+b_aux) == 0
                                        X = X+a_aux;
                                        Y = Y+b_aux;
                                        if Matrice_Labirinto(X,Y) == 1000
                                            Flag_victory = 1;
                                        end
                                        Matrice_movimenti(X,Y,N) = Matrice_movimenti(X,Y,N)+1;
                                        Counter_aux = 0;
                                    end
                                    
                                    
                                    
                                    if Matrice_Labirinto(X,Y) == -100 && Soglia_Neuroni(X,Y) == 0
                                        X = X-a_aux;
                                        Y = Y-b_aux;
                                        for xcx =1:1:12
                                            for ycy =1:1:Larghezza
                                                if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                                    Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                                    Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                                end
                                            end
                                        end
                                        for xcx =1:1:20
                                            for ycy =15:1:Larghezza
                                                if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                                    Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                                    Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                                end
                                            end
                                        end
                                        Counter_aux = 0;
                                        break;
                                    end
                                end
                            end
                            if Counter_aux > 50 && X+a_aux > 0 && X+a_aux <= Altezza && Y+b_aux > 0 && Y+b_aux <= Larghezza
                                if Matrice_Labirinto(X+a_aux,Y+b_aux) ~= -100
                                    X = X+a_aux;
                                    Y = Y+b_aux;
                                end
                                Soglia_Neuroni(X,Y)  = 0.8*Soglia_nominale;
                                Aggiorna_soglia(X,Y) = 0.8*Soglia_nominale;
                                for xcx =1:1:12
                                    for ycy =1:1:Larghezza
                                        if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                            Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                            Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                        end
                                    end
                                end
                                for xcx =1:1:20
                                    for ycy =15:1:Larghezza
                                        if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                            Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                            Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                        end
                                    end
                                end                                
                                Matrice_movimenti(X,Y,N) = Matrice_movimenti(X,Y,N)+1;
                                Counter_aux = 0;
                                break;
                            end
                        end
                        if Flag_victory == 1
                            for dfg = (Step_R-4):1:Step_R
                                if Step_R > 10
                                    Aggiorna_soglia(Matrice_Ricorda(1,dfg),Matrice_Ricorda(2,dfg)) = 0;
                                    Esci = 1;
                                end
                            end
                        end
                    end
                    
                case 6
                    
                    if Soglia_Neuroni(X,Y)~=0
                        
                        X_old=X;
                        Y_old=Y;
                        X=X+1;
                        Y=Y-1;
                        
                        Matrice_sinapsi_S_O(X_old,Y_old,1) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
                        Matrice_sinapsi_S_O(X_old,Y_old,2) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
                        Soglia_Neuroni(X_old,Y_old) = 3*Soglia_nominale;
                        
                        if Matrice_Labirinto(X,Y) == -100
%                             Matrice_sinapsi_S_O(X_old,Y_old,1) = 10.^-random('Uniform',log10(0.9*HRS),log10(1.1*HRS));
%                             Matrice_sinapsi_S_O(X_old,Y_old,2) = 10.^-random('Uniform',log10(0.9*HRS),log10(1.1*HRS));
                            Soglia_Neuroni(X,Y) = 10*Soglia_nominale;
                            Aggiorna_soglia(X,Y) = 10*Soglia_nominale;
                            if X_old == Altezza-1 || Y_old == Larghezza-1 || X_old == 2 || Y_old ==2
                                Matrice_Labirinto(X_old,Y_old) = -100;
                            end
                            if X_old == Altezza-2 || Y_old == Larghezza-2 || X_old == 3
                                Matrice_Labirinto(X_old,Y_old) = -100;
                            end
                            X = X_old;
                            Y = Y_old;
                        end
                        
                        Matrice_Ricorda(1,Step_R)= X;
                        Matrice_Ricorda(2,Step_R)= Y;
                        Matrice_Ricorda(3,Step_R)= t;
                        
                        Step_R = Step_R +1;
                        
                        if Step_R > Step_Recorded
                            Step_R = 1;
                        end
                        
                        
                        if Matrice_Labirinto(X,Y) == 1000
                            Vettore_Migl(1,N) = t;
                            for dfg = (Step_R-50):1:Step_R
                                if Step_R > 50
                                    Aggiorna_soglia(Matrice_Ricorda(1,dfg),Matrice_Ricorda(2,dfg)) = 0;
                                    Esci = 1;
                                end
                            end
                        end
                        
                        Integrazione_N   = 0*Integrazione_N;
                        Integrazione_N_E = 0*Integrazione_N_E;
                        Integrazione_E   = 0*Integrazione_E;
                        Integrazione_S_E = 0*Integrazione_S_E;
                        Integrazione_S   = 0*Integrazione_S;
                        Integrazione_S_O = 0*Integrazione_S_O;
                        Integrazione_O   = 0*Integrazione_O;
                        Integrazione_N_O = 0*Integrazione_N_O;
                        
                    else
                        
                        while Matrice_Labirinto(X,Y)~= 1000
                            Vettore_Migl(1,N) = t;
                            Counter_aux = Counter_aux +1;
                            if Matrice_passaggi(X,Y) < 100
                                Matrice_passaggi(X,Y) = Matrice_passaggi(X,Y)+1;
                            end
                      
                            a_aux = randi([-1 1]);
                            b_aux = randi([-1 1]);
                            
                            if X+a_aux > 0 && X+a_aux <= Altezza
                                if Y+b_aux > 0 && Y+b_aux <= Larghezza
                                    if Soglia_Neuroni(X+a_aux,Y+b_aux) == 0
                                        X = X+a_aux;
                                        Y = Y+b_aux;
                                        if Matrice_Labirinto(X,Y) == 1000
                                            Flag_victory = 1;
                                        end
                                        Matrice_movimenti(X,Y,N) = Matrice_movimenti(X,Y,N)+1;
                                        Counter_aux = 0;
                                    end
                                    
                                    
                                    
                                    if Matrice_Labirinto(X,Y) == -100 && Soglia_Neuroni(X,Y) == 0
                                        X = X-a_aux;
                                        Y = Y-b_aux;
                                        for xcx =1:1:12
                                            for ycy =1:1:Larghezza
                                                if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                                    Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                                    Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                                end
                                            end
                                        end
                                        for xcx =1:1:20
                                            for ycy =15:1:Larghezza
                                                if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                                    Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                                    Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                                end
                                            end
                                        end
                                        Counter_aux = 0;
                                        break;
                                    end
                                end
                            end
                            if Counter_aux > 50 && X+a_aux > 0 && X+a_aux <= Altezza && Y+b_aux > 0 && Y+b_aux <= Larghezza
                                if Matrice_Labirinto(X+a_aux,Y+b_aux) ~= -100
                                    X = X+a_aux;
                                    Y = Y+b_aux;
                                end
                                Soglia_Neuroni(X,Y)  = 0.8*Soglia_nominale;
                                Aggiorna_soglia(X,Y) = 0.8*Soglia_nominale;
                                for xcx =1:1:12
                                    for ycy =1:1:Larghezza
                                        if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                            Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                            Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                        end
                                    end
                                end
                                for xcx =1:1:20
                                    for ycy =15:1:Larghezza
                                        if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                            Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                            Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                        end
                                    end
                                end                                
                                Matrice_movimenti(X,Y,N) = Matrice_movimenti(X,Y,N)+1;
                                Counter_aux = 0;
                                break;
                            end
                        end
                        if Flag_victory == 1
                            for dfg = (Step_R-4):1:Step_R
                                if Step_R > 10
                                    Aggiorna_soglia(Matrice_Ricorda(1,dfg),Matrice_Ricorda(2,dfg)) = 0;
                                    Esci = 1;
                                end
                            end
                        end
                    end
                    
                case 7
                    
                    if Soglia_Neuroni(X,Y)~=0
                        
                        X_old=X;
                        Y_old=Y;
                        X=X+0;
                        Y=Y-1;
                        
                        Matrice_sinapsi_O(X_old,Y_old,1) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
                        Matrice_sinapsi_O(X_old,Y_old,2) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
                        Soglia_Neuroni(X_old,Y_old) = 3*Soglia_nominale;
                        
                        if Matrice_Labirinto(X,Y) == -100
%                             Matrice_sinapsi_O(X_old,Y_old,1) = 10.^-random('Uniform',log10(0.9*HRS),log10(1.1*HRS));
%                             Matrice_sinapsi_O(X_old,Y_old,2) = 10.^-random('Uniform',log10(0.9*HRS),log10(1.1*HRS));
                            Soglia_Neuroni(X,Y) = 10*Soglia_nominale;
                            Aggiorna_soglia(X,Y) = 10*Soglia_nominale;
                            if X_old == Altezza-1 || Y_old == Larghezza-1 || X_old == 2 || Y_old ==2
                                Matrice_Labirinto(X_old,Y_old) = -100;
                            end
                            if X_old == Altezza-2 || Y_old == Larghezza-2 || X_old == 3
                                Matrice_Labirinto(X_old,Y_old) = -100;
                            end
                            X = X_old;
                            Y = Y_old;
                        end
                        
                        Matrice_Ricorda(1,Step_R)= X;
                        Matrice_Ricorda(2,Step_R)= Y;
                        Matrice_Ricorda(3,Step_R)= t;
                        
                        Step_R = Step_R +1;
                        
                        if Step_R > Step_Recorded
                            Step_R = 1;
                        end
                        
                        
                        if Matrice_Labirinto(X,Y) == 1000
                            Vettore_Migl(1,N) = t;
                            for dfg = (Step_R-50):1:Step_R
                                if Step_R > 50
                                    Aggiorna_soglia(Matrice_Ricorda(1,dfg),Matrice_Ricorda(2,dfg)) = 0;
                                    Esci = 1;
                                end
                            end
                        end
                        
                        Integrazione_N   = 0*Integrazione_N;
                        Integrazione_N_E = 0*Integrazione_N_E;
                        Integrazione_E   = 0*Integrazione_E;
                        Integrazione_S_E = 0*Integrazione_S_E;
                        Integrazione_S   = 0*Integrazione_S;
                        Integrazione_S_O = 0*Integrazione_S_O;
                        Integrazione_O   = 0*Integrazione_O;
                        Integrazione_N_O = 0*Integrazione_N_O;
                        
                    else
                        
                        while Matrice_Labirinto(X,Y)~= 1000
                            Vettore_Migl(1,N) = t;
                            Counter_aux = Counter_aux +1;
                            if Matrice_passaggi(X,Y) < 100
                                Matrice_passaggi(X,Y) = Matrice_passaggi(X,Y)+1;
                            end
                      
                            a_aux = randi([-1 1]);
                            b_aux = randi([-1 1]);
                            
                            if X+a_aux > 0 && X+a_aux <= Altezza
                                if Y+b_aux > 0 && Y+b_aux <= Larghezza
                                    if Soglia_Neuroni(X+a_aux,Y+b_aux) == 0
                                        X = X+a_aux;
                                        Y = Y+b_aux;
                                        if Matrice_Labirinto(X,Y) == 1000
                                            Flag_victory = 1;
                                        end
                                        Matrice_movimenti(X,Y,N) = Matrice_movimenti(X,Y,N)+1;
                                        Counter_aux = 0;
                                    end
                                    
                                    
                                    
                                    if Matrice_Labirinto(X,Y) == -100 && Soglia_Neuroni(X,Y) == 0
                                        X = X-a_aux;
                                        Y = Y-b_aux;
                                        for xcx =1:1:12
                                            for ycy =1:1:Larghezza
                                                if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                                    Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                                    Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                                end
                                            end
                                        end
                                        for xcx =1:1:20
                                            for ycy =15:1:Larghezza
                                                if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                                    Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                                    Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                                end
                                            end
                                        end
                                        Counter_aux = 0;
                                        break;
                                    end
                                end
                            end
                            if Counter_aux > 50 && X+a_aux > 0 && X+a_aux <= Altezza && Y+b_aux > 0 && Y+b_aux <= Larghezza
                                if Matrice_Labirinto(X+a_aux,Y+b_aux) ~= -100
                                    X = X+a_aux;
                                    Y = Y+b_aux;
                                end
                                Soglia_Neuroni(X,Y)  = 0.8*Soglia_nominale;
                                Aggiorna_soglia(X,Y) = 0.8*Soglia_nominale;
                                for xcx =1:1:12
                                    for ycy =1:1:Larghezza
                                        if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                            Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                            Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                        end
                                    end
                                end
                                for xcx =1:1:20
                                    for ycy =15:1:Larghezza
                                        if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                            Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                            Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                        end
                                    end
                                end                                
                                Matrice_movimenti(X,Y,N) = Matrice_movimenti(X,Y,N)+1;
                                Counter_aux = 0;
                                break;
                            end
                        end
                        if Flag_victory == 1
                            for dfg = (Step_R-4):1:Step_R
                                if Step_R > 10
                                    Aggiorna_soglia(Matrice_Ricorda(1,dfg),Matrice_Ricorda(2,dfg)) = 0;
                                    Esci = 1;
                                end
                            end
                        end
                    end
                    
                case 8
                    
                    if Soglia_Neuroni(X,Y)~=0
                        
                        X_old=X;
                        Y_old=Y;
                        X=X-1;
                        Y=Y-1;
                        
                        Matrice_sinapsi_N_O(X_old,Y_old,1) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
                        Matrice_sinapsi_N_O(X_old,Y_old,2) = 10.^-random('Uniform',log10(0.9*LRS),log10(1.1*LRS));
                        Soglia_Neuroni(X_old,Y_old) = 3*Soglia_nominale;
                        
                        if Matrice_Labirinto(X,Y) == -100
%                             Matrice_sinapsi_N_O(X_old,Y_old,1) = 10.^-random('Uniform',log10(0.9*HRS),log10(1.1*HRS));
%                             Matrice_sinapsi_N_O(X_old,Y_old,2) = 10.^-random('Uniform',log10(0.9*HRS),log10(1.1*HRS));
                            Soglia_Neuroni(X,Y) = 10*Soglia_nominale;
                            Aggiorna_soglia(X,Y) = 10*Soglia_nominale;
                            if X_old == Altezza-1 || Y_old == Larghezza-1 || X_old == 2 || Y_old ==2
                                Matrice_Labirinto(X_old,Y_old) = -100;
                            end
                            if X_old == Altezza-2 || Y_old == Larghezza-2 || X_old == 3
                                Matrice_Labirinto(X_old,Y_old) = -100;
                            end
                            X = X_old;
                            Y = Y_old;
                        end
                        
                        Matrice_Ricorda(1,Step_R)= X;
                        Matrice_Ricorda(2,Step_R)= Y;
                        Matrice_Ricorda(3,Step_R)= t;
                        
                        Step_R = Step_R +1;
                        
                        if Step_R > Step_Recorded
                            Step_R = 1;
                        end
                        
                        
                        if Matrice_Labirinto(X,Y) == 1000
                            Vettore_Migl(1,N) = t;
                            for dfg = (Step_R-50):1:Step_R
                                if Step_R > 50
                                    Aggiorna_soglia(Matrice_Ricorda(1,dfg),Matrice_Ricorda(2,dfg)) = 0;
                                    Esci = 1;
                                end
                            end
                        end
                        
                        Integrazione_N   = 0*Integrazione_N;
                        Integrazione_N_E = 0*Integrazione_N_E;
                        Integrazione_E   = 0*Integrazione_E;
                        Integrazione_S_E = 0*Integrazione_S_E;
                        Integrazione_S   = 0*Integrazione_S;
                        Integrazione_S_O = 0*Integrazione_S_O;
                        Integrazione_O   = 0*Integrazione_O;
                        Integrazione_N_O = 0*Integrazione_N_O;
                        
                    else
                        
                        while Matrice_Labirinto(X,Y)~= 1000
                            Vettore_Migl(1,N) = t;
                            Counter_aux = Counter_aux +1;
                            if Matrice_passaggi(X,Y) < 100
                                Matrice_passaggi(X,Y) = Matrice_passaggi(X,Y)+1;
                            end
                      
                            a_aux = randi([-1 1]);
                            b_aux = randi([-1 1]);
                            
                            if X+a_aux > 0 && X+a_aux <= Altezza
                                if Y+b_aux > 0 && Y+b_aux <= Larghezza
                                    if Soglia_Neuroni(X+a_aux,Y+b_aux) == 0
                                        X = X+a_aux;
                                        Y = Y+b_aux;
                                        if Matrice_Labirinto(X,Y) == 1000
                                            Flag_victory = 1;
                                        end
                                        Matrice_movimenti(X,Y,N) = Matrice_movimenti(X,Y,N)+1;
                                        Counter_aux = 0;
                                    end
                                    
                                    
                                    
                                    if Matrice_Labirinto(X,Y) == -100 && Soglia_Neuroni(X,Y) == 0
                                        X = X-a_aux;
                                        Y = Y-b_aux;
                                        for xcx =1:1:12
                                            for ycy =1:1:Larghezza
                                                if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                                    Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                                    Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                                end
                                            end
                                        end
                                        for xcx =1:1:20
                                            for ycy =15:1:Larghezza
                                                if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                                    Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                                    Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                                end
                                            end
                                        end
                                        Counter_aux = 0;
                                        break;
                                    end
                                end
                            end
                            if Counter_aux > 50 && X+a_aux > 0 && X+a_aux <= Altezza && Y+b_aux > 0 && Y+b_aux <= Larghezza
                                if Matrice_Labirinto(X+a_aux,Y+b_aux) ~= -100
                                    X = X+a_aux;
                                    Y = Y+b_aux;
                                end
                                Soglia_Neuroni(X,Y)  = 0.8*Soglia_nominale;
                                Aggiorna_soglia(X,Y) = 0.8*Soglia_nominale;
                                for xcx =1:1:12
                                    for ycy =1:1:Larghezza
                                        if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                            Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                            Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                        end
                                    end
                                end
                                for xcx =1:1:20
                                    for ycy =15:1:Larghezza
                                        if Soglia_Neuroni(xcx,ycy) == 0 || Aggiorna_soglia(xcx,ycy) == 0
                                            Soglia_Neuroni(xcx,ycy)  = 0.8*Soglia_nominale;
                                            Aggiorna_soglia(xcx,ycy) = 0.8*Soglia_nominale;
                                        end
                                    end
                                end                                
                                Matrice_movimenti(X,Y,N) = Matrice_movimenti(X,Y,N)+1;
                                Counter_aux = 0;
                                break;
                            end
                        end
                        if Flag_victory == 1
                            for dfg = (Step_R-4):1:Step_R
                                if Step_R > 10
                                    Aggiorna_soglia(Matrice_Ricorda(1,dfg),Matrice_Ricorda(2,dfg)) = 0;
                                    Esci = 1;
                                end
                            end
                        end
                    end
                    
                case 0
                    
                  %THIS ADDITIONAL CASE IS FOR MAPPING THE ASYNCHRONOUS
                  %SPIKING ACTIVITY OF STDP INDUCED BY NOISE
                    
                    if Matrice_movimenti(X,Y,N) >= 30
                        
                        for cx=-1:1:1
                            for cy=-1:1:1
                                if Matrice_movimenti(X+cx,Y+cy,N) ~= -100
                                    Soglia_Neuroni(X+cx,Y+cy)=Soglia_nominale;
                                end
                            end
                        end
                        
                        
                    end
                    
            end  
            
            Flag = 0;
            
%THERE ARE HERE SOME PLOTS FOR INTERMEDIATE STUDIES: UNCOMMENT THESE PARTS IF NEEDED   
            
%             if N < num_trials/3
%                 
%                 figure(N+1);image((Matrice_movimenti(:,:,N)+Matrice_Labirinto_1),'CDataMapping','Scaled');caxis([-100 5]);colormap('autumn');set(gca,'dataaspectratio',[1 1 1]);
%                 ax = gca;ax.FontSize = 12;ax.LineWidth = 1.5;
%             end
%             
%             if N >= num_trials/3 && N < num_trials*2/3
%                 
%                 figure(N+1);image((Matrice_movimenti(:,:,N)+Matrice_Labirinto_2_2),'CDataMapping','Scaled');caxis([-100 5]);colormap('autumn');set(gca,'dataaspectratio',[1 1 1]);
%                 ax = gca;ax.FontSize = 12;ax.LineWidth = 1.5;
%             end
%             
%             if N >= num_trials*(2/3)
%                 
%                 figure(N+1);image((Matrice_movimenti(:,:,N)+Matrice_Labirinto_1),'CDataMapping','Scaled');caxis([-100 5]);colormap('autumn');set(gca,'dataaspectratio',[1 1 1]);
%                 ax = gca;ax.FontSize = 12;ax.LineWidth = 1.5;
%             end

            % THE POSITION OF THE ENVIRONMENT IS RECORDED AND PLOTTED USING AN ARBITRARY
            % DEFINITION OF THE POSITION ITSELF

            Aux_time(N,t) = Magica(X,Y);
            
        else
         
            %THIS PART OF THE CODE HAS BEEN PROVIDED IN ORDER TO EMULATE
            %BEHAVIORALLY THE REWARDED PATH. FOR THE REAL BEHAVIOR, PLEASE
            %REFER TO THE EXPERIMENTAL MEASUREMENTS PROVIDED WITH THE PAPER
            
            for xtx =1:1:30
                for yty =1:1:30
                    if Aggiorna_soglia(xtx,yty)==0
                        Aux_time(N,t+t_xaux) = Magica(xtx,yty);
                    end
                    t_xaux = t_xaux +1;
                end
            end
            
            t_xaux = 0;
            
        end
        
        
        
    end
    
%     pause;

    Aux_time(Aux_time==0)=nan;%For plotting
    
    %IN THE FOLLOWING PLOT WE TRACK THE EVOLUTION OF THE POSITION COVERED
    %BY THE AGENT: THIS IS AN ARBITRARY TYPE OF GRAPH USEFUL FOR FASTER
    %DEBUG
    
    figure(175);plot((1+(N-1)*100):1:(N*100),Aux_time(N,1:1:100),'-b');xlabel('Positions x Trials');ylabel('Positions of the maze');ylim([1 900]);hold on;ax = gca;ax.FontSize = 12;ax.LineWidth = 1.5;set(gcf,'Color','w');
    
    for tx =1:1:Altezza
        for ty =1:1:Larghezza
            
            
            if Matrice_Labirinto(tx,ty)==1000
                Aggiorna_soglia(tx,ty)=0;
            end
            
            
        end
    end
    
    Soglia_Neuroni = Aggiorna_soglia;
    Esci = 0;
    Matrice_Ricorda = ones(Posizioni_matr,Step_Recorded);

    % PROVIDE DIFFERENT INITIAL CONDITIONS --> TO OBSERVE RECALL A CONSTANT
    % INITIAL CONDITION IS ADVISED; DO NOT PUT INITIAL CONDITIONS DIRECTLY ON THE
    % WALLS
    
    if N < num_trials/8
        
        X  = 4;
        Y  = 28;
        
    end
    
    if N >= num_trials/8 && N < num_trials*2/8
        
        X  = 21;%4;
        Y  = 3;%28;
        
    end
    
    if N >= num_trials*2/8 && N < num_trials*3/8
        
        X  = 28;%4;
        Y  = 3;%28;
        
    end
    
    if N >= num_trials*3/8 && N < num_trials*4/8
        
        X  = 15;%4;
        Y  = 5;%28;
        
    end  
    
    if N >= num_trials*4/8 && N < num_trials*5/8
        
        X  = 4;
        Y  = 28;
        
    end
    if N >= num_trials*5/8 && N < num_trials*6/8
        
        X  = 4;
        Y  = 28;
        
    end
    
    if N >= num_trials*6/8 && N < num_trials*7/8
        
        X  = 4;
        Y  = 28;
        
    end
    
    
    if N >= num_trials*(7/8)
        
        X  = 4;
        Y  = 28;
        
    end
    
    Flag_victory = 0;
    
end

% IN ORDER TO MAKE MORE VISIBLE THE RESULTS BY A GRAPHICAL POINT OF VIEW,
% AN ARBITRARY POST-PROVESSING OF THE RESULTS IS HERE PROVIDED. THERE IS NO
% RELATION WITH THE BIO-INSPIRED REINFORCEMENT LEANRING ALGORITHM

for txx =1:1:Altezza
    for tyy =1:1:Larghezza
        
        if Soglia_Neuroni(txx,tyy) == 0
            
            Soglia_Neuroni(txx,tyy) = 0.0000001;
            
            
        end
        
        if (Soglia_Neuroni(txx,tyy) == 100000000*Soglia_nominale)
            
            Soglia_Neuroni(txx,tyy) = 0.001;
            
        end
        
    end
end

Z = Soglia_Neuroni;
Aux_Homeostasis_2 = Aux_Homeostasis + Z;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Aux_Homeostasis_4 = Aux_Homeostasis_2;

for x = 1:1:30
    for y =1:1:30
        Aux_Homeostasis_4(x,y)=Aux_Homeostasis_4(x,y)-min(min(Aux_Homeostasis_2));
        Aux_Homeostasis_4(x,y)=Aux_Homeostasis_4(x,y)*(100/max(max(Aux_Homeostasis_2)));
    end
end

figure(400);set(gcf,'Color','w');hold on;
[X,Y] = meshgrid(1:1:Altezza,Larghezza:-1:1);
surf(X,Y,Aux_Homeostasis_4);
grid off;
shading interp
view(2);
xlim([1 30]);ylim([1 30]);zlim([0 100]);set(gcf,'Color','w');ax = gca;ax.FontSize = 12;ax.LineWidth = 1.5;title('Homeostatic mapping of the environment [% of passage in multiple experiments]');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for txxx =1:1:Altezza
    for tyyy =1:1:Larghezza
        
        if Matrice_passaggi(txxx,tyyy) > 100
            
            Matrice_passaggi(txxx,tyyy) = 100;
            
        end
        
    end
end

figure(201);set(gcf,'Color','w');hold on;
[X,Y] = meshgrid(1:1:Altezza,Larghezza:-1:1);
Z1 = Matrice_passaggi;
Aux_Passaggi = Aux_Passaggi + Matrice_passaggi;
surf(X,Y,Aux_Passaggi);
shading interp
view(2);
grid off;
xlim([1 30]);ylim([1 30]);title('Policy Map created by Unsupervised Learning');ax = gca;ax.FontSize = 12;ax.LineWidth = 1.5;set(gcf,'Color','w');

Vettore_aux_tempo = Vettore_Migl(1,:);

figure(203);semilogy(1:numel(Vettore_Migl(1,:)),Vettore_aux_tempo(1,:),'*b');title('Time improvement after experience');xlabel('Successes');ylabel('Time [a.u.]');
set(gcf,'Color','w');hold on;ax = gca;ax.FontSize = 12;ax.LineWidth = 1.5;