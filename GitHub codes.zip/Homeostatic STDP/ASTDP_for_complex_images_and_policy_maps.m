% GENERIC CODE FOR HOMEOSTATIC STDP IN WINNER TAKE ALL CONFIGURATION

% THIS CODE, IS A HIGH-LEVEL REPRESENTATION OF THE HARDWARE DESIGNED IN THE
% PAPER "A SELF-ADAPTIVE HARDWARE WITH RESISTIVE SWITCHING SYNAPSES FOR 
% EXPERIENCE-BASED NEUROCOMPUTING" by Stefano Bianchi, Irene Munoz Martin
% et al.

% THE CODE CAN BE MODIFIED ACCORDINGLY TO THE NECESSITY. SINCE IN THE PAPER
% WE PROPOSE SEVERAL USES FOR THE STDP, WE PROPOSE HERE AS STARTING CODE
% THE MOST DIFFICULT SITUATION, IN WHICH SEVERAL COMPETING PATTERNS, E.G.
% IMAGES TAKEN FROM A DATASET, HAVE TO BE LEARNT DURING DIFFERENT NEURONAL ACTIVITIES.
% POLICY MAPS FROM THE REINFORCMENT ALGORITHM ARE ALSO PRESENT IN THIS
% FOLDER. PLEASE, ADJUST THE SIZE OF THE PATTERNS ACCORDINGLY TO MAKE THE
% CODE CORRECTLY RUNNING (SEE PARAMETER SECTION HERE BELOW). 

% DUE TO NON-DISCOLOSURE AGREEMENTS, SOME SENSIBLE DATA ARE SIMPLIFIED
% USING ARBITRARY VALUES: FOR RRAM-BASED
% ANALYSIS, STATISTICS, CHOICES OF THE HARDWARE, PLEASE ASK DIRECTLY TO THE
% CORRESPONDING AUTHOR OF THIS PAPER

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% clear all
% close all
load('Images_to_learn.mat');

%PARAMETERS OF STDP - HOMEOSTATIC

Num_neur        = 10; 
altezza         = 28; 
larghezza       = 28;
Num_out_neurons = 10;
LRS             = 10e3;
HRS             = 2e6;
totale          = 100;
time            = 10000; % Then scaled
time_aux        = 20; % Auxiliary variable
colpi_time      = [1 2 3 4 5 6 7 8 9 10];
colpi_time_aux  = colpi_time(1);
Percentuale_P   = 0.75; 
V_TE            = 0.08;
Soglia_nominale = 8.7e-5;
Colpi_soglia    = [1 2 4 6.7 8 8.5 9 10];
Density_noise   = 0.08; %Noise density
axc             = 1;
j               = 1;
Altro_neurone   = 1;
auxx            = 1;
After_noise     = 0;


% VARIABLES

pattern              = zeros(altezza,larghezza,Num_out_neurons);
backgr               = zeros(altezza,larghezza,Num_out_neurons);
Dummy_HRS            = HRS.*ones(altezza,larghezza);
Dummy_LRS            = LRS.*ones(altezza,larghezza);
Synapse              = 10.^-random('Uniform',log10(LRS),log10(HRS),altezza,larghezza,Num_out_neurons);
Synapse_aux          = Synapse;
Synapses_dummmy      = 10.^-random('Uniform',log10(HRS),log10(HRS),altezza,larghezza);
Integrator_Post      = zeros(1,Num_out_neurons);
Diff_corrente        = zeros(1,time);
Soglia               = Soglia_nominale*ones(1,Num_out_neurons);
Tempo_fire           = zeros(1,Num_out_neurons);
num_colpi            = ones(1,Num_out_neurons);
Evolution            = struct;
num_pattern          = zeros(time,Num_out_neurons);
num_backgr           = zeros(time,Num_out_neurons);
Average_syn_pattern  = zeros(time,Num_out_neurons);
Average_syn_backgr   = zeros(time,Num_out_neurons);
ll                   = zeros(1,Num_out_neurons);
lb                   = zeros(1,Num_out_neurons);
Frequenza_sparo      = zeros(1,time);
Input                = zeros(larghezza,altezza);
Punti_pattern        = zeros(Num_out_neurons,larghezza*altezza);
Punti_backgr         = zeros(Num_out_neurons,larghezza*altezza);
Input_precedente     = zeros(altezza,larghezza,Num_out_neurons);
Integrated_curr      = zeros(2,time);

for i=1:1:Num_out_neurons
    
    Evolution(i).P      = zeros(altezza*larghezza,time);
    Evolution(i).N      = zeros(altezza*larghezza,time);
    Evolution(i).P_aver = zeros(1,time);
    Evolution(i).N_aver = zeros(1,time);
    Evolution(i).time   = zeros(1,time);
    Evolution(i).soglia = zeros(1,time);
    
end

% NOISE PARAMETERS

Num_pixel_noise = floor(Density_noise.*altezza.*larghezza);  

for k = 1:1:Num_out_neurons

    % I SELECT ONLY THE PATTERNS THAT RESEMBLE THE DENSITY OF THE POLICY MAPS OF THE CHOSEN
    % ENVIRONMENT IN ORDER TO MIMIC THE TYPICAL CONDITIONS OF THE WORK
    
    for g = 1:1:30000
        if A(g,1)==k && sum(AA(g,:)) > 110 && sum(AA(g,:)) < 120
            break;
        end
    end
    
    Input(:,:) = reshape(AA(g,:),altezza,larghezza)';

    % DEFINE FOR PLOTTING AND DEBUG PURPOSES WHAT IS PATTERN AND WHAT IS
    % BACKGROUND    
    
    for x1=1:1:altezza
        for y1=1:1:larghezza
            if Input(x1,y1)>0.4
                pattern(x1,y1,k) = Input(x1,y1);
            else
                Input(x1,y1) = 0;
                backgr(x1,y1,k) = 1;
            end
        end
    end
    
    matrice_aux_1 = reshape(AA(g,:),altezza,larghezza);
    matrice_aux_2 = reshape((AA(g,:)-1),altezza,larghezza);
    
    a(1,k) = numel(find(matrice_aux_1));
    b(1,k) = numel(find(matrice_aux_2));
    
    Punti_pattern(k,1:1:a(1,k))   = find(matrice_aux_1);   
    Punti_backgr(k,1:1:b(1,k))    = find(matrice_aux_2);
    
end

%THE CODE CAN BE ITERATED FOR SEVERAL LEARNING ACTIVITIES

for N1 = 1:1:1

    for t =2:1:time
        
        %N AND P ARE RANDOMLY PRESENTED
        %INPUT IS RANDOMLY CHOSONE BETWEEN NOISE AND PATTERN
        
        RP = rand(1);
        
        if mod(t,time_aux) == 0
            colpi_time_aux = colpi_time_aux +1;
            if colpi_time_aux == 11
                colpi_time_aux = 1;
            end
        end
        
        
        if RP >= 0.5
            
            Input = pattern(:,:,colpi_time(colpi_time_aux));
            
            %DESCRIPTION OF CIRCUITAL CONTROL MECHANISM 
            
            Diff_corrente(1,time) = sum(sum(Input.*(Synapse(:,:,colpi_time(colpi_time_aux)))*V_TE))-sum(sum(Input.*Synapses_dummmy*V_TE));
            
        elseif RP < 0.5
            
            Input = zeros(altezza,larghezza);
            
            for i=1:1:Num_pixel_noise
                x = randi(altezza);
                y = randi(larghezza);
                Input(x,y) = 1;
            end
            
            for cj =1:1:1
                Diff_corrente(1,cj) = sum(sum(Input.*(Synapse(:,:,cj))*V_TE))-sum(sum(Input.*Synapses_dummmy*V_TE));
            end
            
        end
        
        for j =1:1:Num_out_neurons
            
            Matrice_AUX = reshape(Synapse(:,:,j),altezza,larghezza);
            
            for x =1:1:altezza
                for y=1:1:larghezza
                    
                end
            end
            
            Integrator_Post(1,j) = sum(sum(V_TE.*Input.*Matrice_AUX));
            
            Integrated_curr(j,t) = Integrator_Post(1,j);
            
        end
        for j =1:1:Num_out_neurons
            if Integrator_Post(1,j) >= Soglia(1,j) && (1.15*(Num_pixel_noise.*0.08*(1/HRS)) < sum(sum(Input.*Synapses_dummmy)*V_TE))
                                
                
                for x=1:1:altezza
                    for y=1:1:larghezza
                        if Input(x,y) == 1
                            Synapse(x,y,j) = 10.^-random('Uniform',log10(0.95*LRS),log10(1.05*LRS),1);
                        end
                    end
                end
                
                
                Input_precedente(:,:,j) = Input;
                      
                Tempo_fire(1,j) = t;
                
                Sparo = j;
                
                % HOMEOSTASIS CONTROL MECHANISM -- ARBITRARY UNITS FOR NDA
                
                if Colpi_soglia(num_colpi(1,j)) ~= 10
                    num_colpi(1,j)=num_colpi(1,j)+1;
                    Soglia(1,j) = Colpi_soglia(num_colpi(1,j))*Soglia_nominale;
                end
                
                Frequenza_sparo(j,t) = 1;
                Integrator_Post(1,j) = 0;
                
                % NOTE THAT: IT IS POSSIBLE TO CHOOSE AMONG DIFFERENT NEURONAL MODELS SUCH AS
                % HOMEOSTATIC I&F NEURONS OR HOMEOSTATIC I&F NEURONS OR BOTH OF
                % THEM
                
                for xyt = 1:1:10
                    if xyt ~= j
                        Integrator_Post(1,xyt) = 0*Integrator_Post(1,xyt);
                    end
                end
                Integrated_curr(j,t) = Integrator_Post(1,j);
            end
            
            %DEPRESSION
            
            if t == Tempo_fire(1,j)+1 && t ~= 1 
                for x=1:1:28
                    for y=1:1:28
                        if Input(x,y) == 1 && Input_precedente(x,y,j) == 0
                            Synapse(x,y,j) = 10.^-random('Uniform',log10(0.8*HRS),log10(1.2*HRS),1);
                        end
                    end
                end
            end
            
            
            
            % DATA ORGANIZATION
            
            Evolution(j).P(:,t) = reshape(Synapse(:,:,j)',1,altezza.*larghezza);
            Evolution(j).N(:,t) = reshape(Synapse(:,:,j)',1,altezza.*larghezza);
            
            
            for x=1:1:altezza
                for y=1:1:larghezza
                    if pattern(x,y) == 1
                        
                        Average_syn_pattern(t,j) = Average_syn_pattern(t,j) + (Synapse(x,y,j));
                        num_pattern(t,j) = num_pattern(t,j)+1;
                        
                    else
                        
                        Average_syn_backgr(t,j) = Average_syn_backgr(t,j) + (Synapse(x,y,j));
                        num_backgr(t,j) = num_backgr(t,j) + 1;
                        
                    end
                end
            end
            
            Evolution(j).P_aver(t)   = Average_syn_pattern(t,j)/num_pattern(t,j);
            Evolution(j).N_aver(t)   = Average_syn_backgr(t,j)/num_backgr(t,j);
            Evolution(j).time(t)     = Tempo_fire(1,j);
            Evolution(j).soglia(t)   = Soglia(1,j);
            
            if mod(t,time) == 0
                
                for jkl = 1:1:(a(1,1)-60) % Only for faster pattern representation
                    ll = Punti_pattern(1,jkl);
                    lb = Punti_backgr(1,jkl);
                    figure(1);semilogy((2:1:time),Evolution(1).P(ll,2:1:end),'r');hold on;
                    semilogy((2:1:time),Evolution(1).N(lb,2:end),'-c');hold on;
                end
 
                for jkl = 1:1:(a(1,2)-60)
                    ll = Punti_pattern(2,jkl);
                    lb = Punti_backgr(2,jkl);
                    figure(2);semilogy((2:1:time),Evolution(2).P(ll,2:1:end),'r');hold on;
                    semilogy((1:1:time),Evolution(2).N(lb,:),'-c');hold on;
                end     
                
                for jkl = 1:1:(a(1,3)-60)
                    ll = Punti_pattern(3,jkl);
                    lb = Punti_backgr(3,jkl);
                    figure(3);semilogy((2:1:time),Evolution(3).P(ll,2:1:end),'r');hold on;
                    semilogy((1:1:time),Evolution(3).N(lb,:),'-c');hold on;
                end
                
                for jkl = 1:1:(a(1,4)-60)
                    ll = Punti_pattern(4,jkl);
                    lb = Punti_backgr(4,jkl);
                    figure(4);semilogy((2:1:time),Evolution(4).P(ll,2:1:end),'r');hold on;
                    semilogy((1:1:time),Evolution(4).N(lb,:),'-c');hold on;
                end
                for jkl = 1:1:(a(1,5)-60)
                    ll = Punti_pattern(5,jkl);
                    lb = Punti_backgr(5,jkl);
                    figure(5);semilogy((2:1:time),Evolution(5).P(ll,2:1:end),'r');hold on;
                    semilogy((1:1:time),Evolution(5).N(lb,:),'-c');hold on;
                end
                for jkl = 1:1:(a(1,6)-60)
                    ll = Punti_pattern(6,jkl);
                    lb = Punti_backgr(6,jkl);
                    figure(6);semilogy((2:1:time),Evolution(6).P(ll,2:1:end),'r');hold on;
                    semilogy((1:1:time),Evolution(6).N(lb,:),'-c');hold on;
                end
                for jkl = 1:1:(a(1,7)-60)
                    ll = Punti_pattern(7,jkl);
                    lb = Punti_backgr(7,jkl);
                    figure(7);semilogy((2:1:time),Evolution(7).P(ll,2:1:end),'r');hold on;
                    semilogy((2:1:time),Evolution(7).N(lb,2:end),'-c');hold on;
                end
 
                for jkl = 1:1:(a(1,8)-60)
                    ll = Punti_pattern(8,jkl);
                    lb = Punti_backgr(8,jkl);
                    figure(8);semilogy((2:1:time),Evolution(8).P(ll,2:1:end),'r');hold on;
                    semilogy((1:1:time),Evolution(8).N(lb,:),'-c');hold on;
                end     
                
                for jkl = 1:1:(a(1,9)-60)
                    ll = Punti_pattern(9,jkl);
                    lb = Punti_backgr(9,jkl);
                    figure(9);semilogy((2:1:time),Evolution(9).P(ll,2:1:end),'r');hold on;
                    semilogy((1:1:time),Evolution(9).N(lb,:),'-c');hold on;
                end
                
                for jkl = 1:1:(a(1,10)-60)
                    ll = Punti_pattern(10,jkl);
                    lb = Punti_backgr(10,jkl);
                    figure(10);semilogy((2:1:time),Evolution(10).P(ll,2:1:end),'r');hold on;
                    semilogy((1:1:time),Evolution(10).N(lb,:),'-c');hold on;
                end                
            end
            
        end
        
    end
    
end