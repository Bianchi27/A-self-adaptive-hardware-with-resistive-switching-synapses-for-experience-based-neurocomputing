%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%STDP PATTERN FREQUENCY: MODELLING OF LEARNING TIME

% THIS CODE, IS A HIGH-LEVEL REPRESENTATION OF THE HARDWARE STDP MODELLING FOR THE
% PAPER "A SELF-ADAPTIVE HARDWARE WITH RESISTIVE SWITCHING SYNAPSES FOR 
% EXPERIENCE-BASED NEUROCOMPUTING" by Stefano Bianchi, Irene Munoz Martin
% et al.

% NOTE THAT THE RRAM VALUES ARE CHOSEN ARBITRARILY

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% clear all
% close all
% clc
Vte    = 0.02;
Gmax   = (20e3)^-1;
Gmin   = (0.5e6)^-1;
A      = 10;
B      = 70e7;
C      = 30e5;
Dt     = 10e-3;
N      = 0.05;
P      = 16/64;
soglia = 7.5e-6;
RP     = 0.5;
Alfa   = 60;
Beta   = 0.69;
noise  = 0.03;
t      = 0:0.0001:4;
RPvect  = 0.08:0.04:0.8;
tau_backgr= 0.07;
Vpend = zeros(numel(RPvect),1);
Vbend = zeros(numel(RPvect),1);
G_soglia = zeros(numel(t),1);
for y=1:1:numel(t)
    G_soglia(y)=1/60000;
end
tlearn=zeros(numel(RPvect));

for k = 1:numel(RPvect)
    RP = RPvect(k);
    kkk  = 1;
    RN   = 1-RP;
    Gp   = zeros(numel(t),1);
    Gb   = zeros(numel(t),1);
    Gp(1)= 10.^(log10(1.95e-5));
    Gb(1)= Gp(1);
    dt   = t(2)-t(1);
    
    for i = 2:numel(t)
        dGp   = (A*N*RN*(Gmax-Gp(i-1)+Gmin-Gp(i-1))+C*(Gmax-Gp(i-1))*(Gp(i-1)-Gmin*Alfa*N)*(P-N)*RP)*dt;
        dGb   = tau_backgr*((A*N*RN*(Gmax-Gb(i-1)+Gmin-Gb(i-1))+B*N*RP*RN*(Beta*Gmax-Gb(i-1))*(Gb(i-1)-Gmin)*(-P+N)*(1-P)*RN*RP))*dt;
        Gp(i) = Gp(i-1) + dGp;
        Gb(i) = Gb(i-1) + dGb;
        if (Gb(i))<1/(65000)&& kkk==1
            tlearn(k)=t(i);
            kkk=0;
        end
        
    end

    Vpend(k) = Gp(end);
    Vbend(k) = Gb(end);

end

figure(1); plot(RPvect,tlearn/0.01,'g');xlim([0 1]); xlabel('Pattern Rate','Fontsize',14);ylabel('Learning epochs','Fontsize',14); hold on;
