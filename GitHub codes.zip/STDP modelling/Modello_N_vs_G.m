%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%STDP NOISE MODELLING

% THIS CODE, IS A HIGH-LEVEL REPRESENTATION OF THE HARDWARE STDP MODELLING FOR THE
% PAPER "A SELF-ADAPTIVE HARDWARE WITH RESISTIVE SWITCHING SYNAPSES FOR 
% EXPERIENCE-BASED NEUROCOMPUTING" by Stefano Bianchi, Irene Munoz Martin
% et al.

% NOTE THAT THE RRAM VALUES ARE CHOSEN ARBITRARILY

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% clear all
% close all
% clc

Vte    = 0.02;
Gmax   = (12e3)^-1;
Gmin   = (1.2e6)^-1;
A      = 10;
B      = 70e7;
C      = 30e5;
Dt     = 10e-3;
N      = 0.05;
P      = 12/64;
soglia = 3.5e-6;
RP     = 0.5;
Alfa   = 60;
Beta   = 0.69;
t      = 0:0.01:10;
Nvect  = 0:0.01:1;
tau_backgr= 0.08;
Vpend = zeros(numel(Nvect),1);
Vbend = zeros(numel(Nvect),1);


for k = 1:numel(Nvect)
    N    = Nvect(k);
    RN   = 1-RP;
    Gp   = zeros(numel(t),1);
    Gb   = zeros(numel(t),1); 

    Gp(1)= 10.^(log10(40e-6));
    Gb(1)= Gp(1);
    dt   = t(2)-t(1);
    
    for i = 2:numel(t)
            dGp   = (A*N*RN*(Gmax-Gp(i-1)+Gmin-Gp(i-1))+C*RP*(Gmax-Gp(i-1))*(Gp(i-1)-Gmin*Alfa*N)*(P-N)*RP)*dt;
            dGb   = tau_backgr*((A*N*RN*(Gmax-Gb(i-1)+Gmin-Gb(i-1))+B*RP*N*RP*RN*(Beta*Gmax-Gb(i-1))*(Gb(i-1)-Gmin)*(-P+N)*(1-P)*RN*RP))*dt;
            Gp(i) = Gp(i-1) + dGp;
            Gb(i) = Gb(i-1) + dGb;
    end
          figure(2); semilogy(t,Gp,'g');hold on;xlabel('Epochs','Fontsize',14);ylabel('G [\Omega^{-1}]','Fontsize',14);

    Vpend(k) = Gp(end);
    Vbend(k) = Gb(end);

end
figure(1); semilogy(Nvect,Vbend,'m',Nvect,Vpend,'k');xlabel('Noise density','Fontsize',14);ylabel('G [S]','Fontsize',14); hold on;
