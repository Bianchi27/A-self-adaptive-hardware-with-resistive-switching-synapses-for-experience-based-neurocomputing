%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%STDP NOISE DENSITY: MODELLING OF LEARNING TIME

% THIS CODE, IS A HIGH-LEVEL REPRESENTATION OF THE HARDWARE STDP MODELLING FOR THE
% PAPER "A SELF-ADAPTIVE HARDWARE WITH RESISTIVE SWITCHING SYNAPSES FOR 
% EXPERIENCE-BASED NEUROCOMPUTING" by Stefano Bianchi, Irene Munoz Martin
% et al.

% NOTE THAT THE RRAM VALUES ARE CHOSEN ARBITRARILY

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% clear all
% close all
% clc
Vte    = 0.02;
Gmax   = (12e3)^-1;
Gmin   = (1.2e6)^-1;
A      = 10;
B      = 70e7;
C      = 30e5;
Dt     = 10e-3;
N      = 0.03;
P      = 16/64;
soglia = 7.5e-6;
RP     = 0.5;
Alfa   = 60;
Beta   = 0.69;
t      = 0:0.0001:10;
Nvect  = 0.0001:0.001:0.20;
tau_backgr= 0.05;
Vpend = zeros(numel(Nvect),1);
Vbend = zeros(numel(Nvect),1);
G_soglia = zeros(numel(t),1);
for y=1:1:numel(t)
   G_soglia(y)=1/70000; 
end
tlearn=zeros(numel(Nvect));

for k = 1:numel(Nvect)
    kkk  = 1;
    N    = Nvect(k);
    RN   = 1-RP;
    Gp   = zeros(numel(t),1);
    Gb   = zeros(numel(t),1);
    Gp(1)= 10.^(log10(1.95e-5));
    Gb(1)= Gp(1);
    dt   = t(2)-t(1);
    
    for i = 2:numel(t)
        dGp   = (A*N*RN*(Gmax-Gp(i-1)+Gmin-Gp(i-1))+C*(Gmax-Gp(i-1))*(Gp(i-1)-Gmin*Alfa*N)*(P-N)*RP)*dt;
        dGb   = tau_backgr*((A*N*RN*(Gmax-Gb(i-1)+Gmin-Gb(i-1))+B*N*RP*RN*(Beta*Gmax-Gb(i-1))*(Gb(i-1)-Gmin)*(-P+N)*(1-P)*RN*RP))*dt;
        Gp(i) = Gp(i-1) + dGp;
        Gb(i) = Gb(i-1) + dGb;
        if (Gb(i))<1/(70000)&& kkk==1
            tlearn(k)=t(i);
            kkk=0;
        end
        
        if N>0.18
            tlearn(k)=0;
        end
        
    end
    if mod(k,100) == 1
        figure(2);semilogy(t/0.01,Gp,'r',t/0.01,Gb,'b');ylim([(2e6)^-1 (10e3)^-1]);hold on;xlabel('Epoch [s]','Fontsize',14);ylabel('G [S]','Fontsize',14);    
    end
    Vpend(k) = Gp(end);
    Vbend(k) = Gb(end);
end
figure(1); plot(Nvect*100,tlearn/0.01,'g');xlabel('Noise density','Fontsize',14);ylabel('Learning epochs','Fontsize',14); hold on;