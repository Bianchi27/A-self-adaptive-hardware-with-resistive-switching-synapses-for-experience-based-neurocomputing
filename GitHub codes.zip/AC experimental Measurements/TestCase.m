% THIS MATLAB FUNCTION IS USED FOR THE HARDWARE DESIGNED IN THE
% PAPER "A SELF-ADAPTIVE HARDWARE WITH RESISTIVE SWITCHING SYNAPSES FOR 
% EXPERIENCE-BASED NEUROCOMPUTING" by Stefano Bianchi, Irene Munoz Martin
% et al.

% SOME DETAILS ARE HIDDEN DUE TO NON-DISCLOSURE AGREEMENTS FOR THE
% RRAM-BASED CHIPS

%% Test 
clear 
clc 
close all

connType = 'Prologix';
gpibAdr = 7;
port = 'COM3';
chVect = [1 2 3 4];
ampVect = [1 1 1 1];
ampUnitVect = {'VPP','VPP','VPP','VPP'};
DCoffsetVect = [0 0 0 0];
ZloadVect = {'OPEN','OPEN','OPEN','OPEN'};
waveVect = {'SINE','COSINE','TRIANG','SINE'};
tsampleVect = [1e-3 2e-3 1e-3 1e-3];
FmodeVect = {'NONE','NONE','NONE','NONE'};
modeVect = {'TRIG','GATE','TRIG','TONE'};

% Trigger
trigSourceVect = {'MAN','MAN','INT','INT'};
trigOutVect = {};
trigPerVect = 20e-3;
trigEdgeVect = {'','POS','POS','POS'};
bstcntVect = [5 1 1 1];


% Sweep
pswp.num = [100 1e6 0.05 2e5];
pswp.str = {'SF','CONT','UP','ON','LOG'};

% Ptone
ptoneVect(4).Frq = [100 200 300 400 500 800];
ptoneVect(4).Mode = 1;

ptoneVect(3).Frq = [100 200 300 400 500 800];
ptoneVect(3).Mode = 1;

% SEQ
pseqVect(1).num = [1 2 3 4];
pseqVect(1).count = [1 1 1 1];
pseqVect(1).name = {'TR1','TR1','TR2','TR1'};
pseqVect(1).step = {'COUNT','COUNT','COUNT','COUNT'};
pseqVect(1).status = {'4','ON'};

% pusle and pulse train
ppulseVect = [];
pptVect = [];

dly = 5e-3;

setWaveTTi_TGA1244(connType,gpibAdr,port,chVect,ampUnitVect,ampVect,waveVect,DCoffsetVect,ZloadVect,tsampleVect,...
    modeVect,trigSourceVect,trigPerVect,trigEdgeVect,trigOutVect,bstcntVect,FmodeVect,ppulseVect,pptVect,pseqVect,pswp,...
    ptoneVect,dly)
%% SYNCOUT 
connType = 'Prologix';
gpibAdr = 5;
port = 'COM3';
chVect = [1 2 3];
syncStVect = {'ON','OFF','OFF'};
syncModeVect = {'TRIGGER','',''};
dly = 5e-3;

syncOutTTi(connType,gpibAdr,port,chVect,syncStVect,syncModeVect,dly)
%% Sweep manual 
connType = 'Prologix';
gpibAdr = 5;
port = 'COM3';
ch = 1;
stMode = false;
stSpeed = 'SLOW';
wrpStatus = 'OFF';
swpDir = 'UP';
dly = 5e-3;

sweepManualTTi(connType,gpibAdr,port,ch,stMode,stSpeed,wrpStatus,swpDir,dly)
