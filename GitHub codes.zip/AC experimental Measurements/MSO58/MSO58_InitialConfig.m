% THIS MATLAB FUNCTION IS USED FOR THE HARDWARE DESIGNED IN THE
% PAPER "A SELF-ADAPTIVE HARDWARE WITH RESISTIVE SWITCHING SYNAPSES FOR 
% EXPERIENCE-BASED NEUROCOMPUTING" by Stefano Bianchi, Irene Munoz Martin
% et al.

% SOME DETAILS ARE HIDDEN DUE TO NON-DISCLOSURE AGREEMENTS

function MSO58_InitialConfig(oscObj,oscch,acqsNum,oscZload,oscBw)
% This function set the Channel status (on/off) and load and bandwidth for selected channel, the
% Acquisition number of Osc. (and Acquisition Mode to off)

if ~strcmp(instrfind(oscObj).status,'open')
    fopen(oscObj);
end

% ====================  Acq. Num setting ====================
fprintf(oscObj,'ACQuire:SEQuence:NUMSEQuence %d',acqsNum);
% Mode
% In order to retreive back the data from Osc, the Osc must be in the Single/Sequence mode
% Also put Osc. in normal mode
fprintf(oscObj,'ACQuire:STOPAfter SEQ');
% State
fprintf(oscObj,'ACQuire:STATE OFF');
% =======================================================

% ====================  Osc Channels ====================
% All Channels OFF
for i = 1:8
    fprintf(oscObj,strcat('DISplay:GLObal:CH',num2str(i),':STATE OFF'));
end

% Selected Channels ON
for i = 1:length(oscch)
    fprintf(oscObj,strcat('DISplay:GLObal:CH',num2str(oscch(i)),':STATE ON'));
end
% =======================================================

% ==================== Channel input configuration (Z, Bw) ====================
for i = 1:length(oscZload)
    fprintf(oscObj,strcat('CH',num2str(oscch(i)),':TERmination %d'),oscZload(i));
    fprintf(oscObj,strcat('CH',num2str(oscch(i)),':BANdwidth %d'),oscBw(i));
end
% =======================================================

fclose(oscObj);
end