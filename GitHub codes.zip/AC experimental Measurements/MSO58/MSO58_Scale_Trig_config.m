% THIS MATLAB FUNCTION IS USED FOR THE HARDWARE DESIGNED IN THE
% PAPER "A SELF-ADAPTIVE HARDWARE WITH RESISTIVE SWITCHING SYNAPSES FOR 
% EXPERIENCE-BASED NEUROCOMPUTING" by Stefano Bianchi, Irene Munoz Martin
% et al.

% SOME DETAILS ARE HIDDEN DUE TO NON-DISCLOSURE AGREEMENTS

function MSO58_Scale_Trig_config(oscObj,oscch,timeStep,timeDiv,timeDly,verDiv,verZero,oscchTrig,edge,trigLev)
% This function is for set the scale and trigger parameters of Osc.

if ~strcmp(instrfind(oscObj).status,'open')
    fopen(oscObj);
end

% ==================== Horizontal configuration ====================
% Hor Mode (Always set to Manual)
fprintf(oscObj,'HORizontal:MODE MANUAL');
% Hor. Delay ON
fprintf(oscObj,'HORizontal:DELay:MODe ON');
% Sample rate changes affect (Horizontal Scale/ Record Length)
fprintf(oscObj,'HORizontal:MODE:MANUAL:CONFIGURE RECORDLength');
% Sample rate (time step)
fprintf(oscObj,'HORizontal:MODE:SAMPLERate %d',1/timeStep);
% Time scale (Hor.)
fprintf(oscObj,'HORizontal:MODE:SCALE %d',timeDiv);
% Hor. Delay
fprintf(oscObj,'HORizontal:DELay:TIME %d',timeDly);
% ==================================================================

% ==================== Vertical configuration ====================
for i = 1:length(oscch)
    fprintf(oscObj,strcat('CH',num2str(oscch(i)),':SCAle %d'),verDiv(i));
    fprintf(oscObj,strcat('CH',num2str(oscch(i)),':POSition %d'),verZero(i));
end
% ================================================================

% ==================== Trigger configuration ====================
% Trigger source
fprintf(oscObj,strcat('TRIGger:A:EDGE:SOURCE CH',oscchTrig));
% Trigger type
fprintf(oscObj,'TRIGger:A:EDGE:SLOpe %s',edge);
% Trigger level
%fprintf(oscObj,strcat('TRIGger:A:LEVEL:CH',oscchTrig,' %d'),trigLev);
fprintf(oscObj,strcat('TRIGger:A:LEVEL:CH',oscchTrig,sprintf(' %.2f',trigLev)));
% ===============================================================

fclose(oscObj);
end