function [oscObj] = MSO58_connect(osc_addr,vendor)
    % Open VISA connection
    oscAddr = strcat('TCPIP::',osc_addr,'::INSTR');
    oscObj = visa(vendor, oscAddr);
    oscObj.InputBufferSize = 1e8;
end