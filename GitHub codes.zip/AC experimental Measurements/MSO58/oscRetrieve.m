% THIS MATLAB FUNCTION IS USED FOR THE HARDWARE DESIGNED IN THE
% PAPER "A SELF-ADAPTIVE HARDWARE WITH RESISTIVE SWITCHING SYNAPSES FOR 
% EXPERIENCE-BASED NEUROCOMPUTING" by Stefano Bianchi, Irene Munoz Martin
% et al.

% SOME DETAILS ARE HIDDEN DUE TO NON-DISCLOSURE AGREEMENTS

function OscData = oscRetrieve(oscObj,oscch)
% It can be used only if the source of the trigger is different otherwise the part before the
% trigger will be lost!

% Selecting the channel that should be read
fprintf(oscObj,':DATa:SOUrce CH1');
% Set the header of received string (0 off \ 1 on)
fprintf(oscObj, ':HEADer 0');

% Number of the points
temp = strsplit(query(oscObj,':WFMOutpre:WFId?'),',');
temp = strsplit(temp{5},' ');
numPoint = int64(str2num(temp{2})); %#ok<*ST2NM>
clear temp

% sample time/ inverse of sample rate
timeStep = str2num(query(oscObj,':WFMOutpre:XINcr?'));

% Trigger Point index- starting point of the trigger respect to first data recieved
trig_ind = int64(str2num(query(oscObj,'WFMOutpre:PT_Off?')));

% ==================== Horizontal Setup ====================
% Horizontal Axis scale
horScale = str2num(query(oscObj,'HORizontal:MODE:SCALE?'));

% Time Vector
if trig_ind<=0
    Time = linspace(0,(10*horScale),numPoint);
else
    Time = linspace(0,(10*horScale),(numPoint-trig_ind)+1);
end
% ===========================================================

% Initilize current vector
if trig_ind<=0
    Curve = zeros(numel(oscch),numPoint);
else
    Curve = zeros(numel(oscch),(numPoint-trig_ind)+1);
end
verScale = zeros(numel(oscch),1);
verZero = zeros(numel(oscch),1);
Ymult = zeros(numel(oscch),1);

% Ending point of the Curve
stp = [':DATa:STOP',' ',num2str(numPoint)];

for i=1:numel(oscch)
    % Selecting the channel that should be read
    fprintf(oscObj, strcat(':DATa:SOUrce CH',num2str(oscch(i))));
    
    % Assigning the starting point
    fprintf(oscObj, ':DATa:START 1');
    % Assigning the ending point
    fprintf(oscObj, stp);
    
    % Set the Type of the data (Binary, ASCI)
    fprintf(oscObj, ':WFMOutpre:ENCdg ASCii');
    % Assign size of each single point for being saved based on Byte (2 B)
    fprintf(oscObj, ':WFMOutpre:BYT_Nr 2');
    
    % ==================== Vertical Setup ====================
    % Vertical Axis scale
    verScale(i) = str2num(query(oscObj,strcat('CH',num2str(oscch(i)),':SCAle?')));
    
    % Vertical Axis delay
    % + shifts downward, - shift upward
    verZero(i) = str2num(query(oscObj,'WFMOutpre:YZEro?'));
    % ===========================================================
    
    % Y multiplier to convert the digitize data to Voltage value
    Ymult(i) = str2num(query(oscObj,'WFMOutpre:YMUlt?'));
    
    % Retrieving data
    data = query(oscObj,':CURVE?');
    curveTemp = str2num(data).*Ymult(i);
    % Real Voltage Curves
    if trig_ind<=0
        Curve(i,:) = curveTemp + sign(verZero(i))*abs(verZero(i));
    else
        Curve(i,:) = curveTemp(trig_ind:end) + sign(verZero(i))*abs(verZero(i));
    end
    clear curveTemp data
end
% Structure with all data information
OscData.Curve = Curve;
OscData.Time = Time;
OscData.timeStep = timeStep;
OscData.verScale = verScale;
OscData.horScale = horScale;
end
