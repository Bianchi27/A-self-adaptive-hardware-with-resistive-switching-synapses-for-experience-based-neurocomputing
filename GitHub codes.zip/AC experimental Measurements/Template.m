% THIS MATLAB CODE IS USED FOR THE HARDWARE DESIGNED IN THE
% PAPER "A SELF-ADAPTIVE HARDWARE WITH RESISTIVE SWITCHING SYNAPSES FOR 
% EXPERIENCE-BASED NEUROCOMPUTING" by Stefano Bianchi, Irene Munoz Martin
% et al.

% SOME DETAILS ARE HIDDEN DUE TO NON-DISCLOSURE AGREEMENTS OF THE
% RRAM-BASED CHIPS

%% Initializing Section
clear
clc
close all

dly = 5e-3;

% ==================== Saving Directroy ====================
% Initilize the path for saving data
reference_path = 'C:\Users\...';
%cd(reference_path);

% Path
t=datetime;
parent_folder = sprintf('%d-%d-%d',day(t),month(t),year(t));
if (~exist(strcat(reference_path,'\',parent_folder),'dir'))
    mkdir(reference_path,parent_folder);
end

% Directory
parentDir = strcat(reference_path,'\',parent_folder);

% ==========================================================

% ====================  pulse generator ====================
connType = 'Prologix';
gpibAdr = 5;
port = 'COM3';

delete(instrfind);
% ==========================================================

% ==================== Osc. Setting ====================
% IP address
oscAddr = '10.79.11.123';

% Visa Vendor that is installed in the pc Example: 'tek','NI','agilent'
vendor = 'NI';

oscObj = MSO58_connect(oscAddr,vendor);

% Number of accuisitions (more than number of points)
acqsNum = 10e3;

% Active Channels
oscch = [1,2,3,4,5,6]; % [1 2 3 4 6];% 
% Termination Impedance of Osc.
oscZload = [50,1e6,1e6,1e6,1e6,1e6]; %[1e6 1e6 1e6 1e6 1e6]; % in Ohm
% Bandwidth of Osc.
oscBw = [20,20,20,20,20,20]*1e6;  %[20 20 20 20 20]*1e6; % in Hz

MSO58_InitialConfig(oscObj,oscch,acqsNum,oscZload,oscBw);
% =======================================================
%% Load Pulse to (Pulse Generator)
% Load the pulse in the folder first
waveStr(1).tr = pulse;
waveNameVect = {'PTEST'};
loadWaveTTi_TGA1244(connType,gpibAdr,port,waveStr,waveNameVect,dly)
%% Set the Pulse generator and Osc. parameter for Exp.

% ==================== Pulse Generator ====================
% All inputs
% Channels setup
chVect = [1 2 3 4];
ampVect = [1 1 1 1];
ampUnitVect = {'VPP','VPP','VPP','VPP'};
DCoffsetVect = [0 0 0 0];
ZloadVect = {'50','50','50','50'};
waveVect = {'PTEST','PTEST','PTEST','PTEST'};
tsampleVect = [500e-9 500e-9 500e-9 500e-9];
FmodeVect = {'NONE','NONE','NONE','NONE'};
modeVect = {'TRIG','TRIG','TRIG','TRIG'};

% Trigger
trigSourceVect = {'MAN','MAN','MAN','MAN'};
trigOutVect = {};
trigPerVect = 20e-3;
trigEdgeVect = {'POS','POS','POS','POS'};
bstcntVect = [1 1 1 1];
% =========================================================

% ==================== Osc. Parameter ====================
% Pulse points (Pulse generator setup)
tp = 60; % Total points
tt = tp*tsampleVect(1); % Total Time

% Horizontal setup
timeDiv = tt/10;
% delay : Left is positive
timeDly = 5*timeDiv;

% Invers of Sample rate
% desired number of point per shortest pulse part
desPt = 100;
timeStep = tsampleVect(1)/desPt; % Time between two points

% check (min record points = 1000 => (100 points for each division)
chk = timeDiv/100;
if timeStep <= chk

% Vertical Setup
verDiv = [500e-6 100e-3 100e-3 100e-3 100e-3 1.5]; %[200e-3 200e-3 200e-3 200e-3 1]; % 
% it is step not Volatage (it shifts zeros to selected position)
verZero = [0 0 0 0 0 0]; % [-4 -4 -4 -4 -4 -4]; % Any Vaòue between -5(Down) to 5(Up)
% All possible scale
% oscVall = [500e-6 1e-3 2e-3 5e-3 10e-3 20e-3 50e-3 100e-3 200e-3 500e-3 1 2 5 10];

% Trigger setup
oscchTrig = '6';
edge = 'RISE';
trigLev = 2.6;
% ========================================================

% OSC.%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
MSO58_Scale_Trig_config(oscObj,oscch,timeStep,timeDiv,timeDly,verDiv,verZero,oscchTrig,edge,trigLev);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% P.G %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
setWaveTTi_TGA1244(connType,gpibAdr,port,chVect,ampUnitVect,ampVect,waveVect,DCoffsetVect,ZloadVect,tsampleVect,...
    modeVect,trigSourceVect,trigPerVect,trigEdgeVect,trigOutVect,bstcntVect,FmodeVect,[],[],[],[],...
    [],dly)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Sync out for triggering the Osc. %%%%%%%%%%%%%%%%%%%%%%%
syncCh = 1; % e.g. [1 2 3 4];
syncStVect = {'ON'}; % e.g. {'ON','OFF','OFF','OFF'};
syncModeVect = {'TRIGGER'}; % e.g. {'TRIGGER','','',''};
syncOutTTi_TGA1244(connType,gpibAdr,port,syncCh,syncStVect,syncModeVect,dly)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
else
    error('Wrong input value for time step');
end
%% Meas.
% Load Vinput(0.3) NEW first 
load('Vinput(0.3) NEW.mat');
[tot,~] = size(V4);
%V(11,2) = -0.0026;

if ~strcmp(instrfind(oscObj).status,'open')
    fopen(oscObj);
end

for c=1:tot
    chVect = [1,2,3,4];
    ampVect = V4(c,:);
    
    ampChangeTTi_TGA1244(connType,gpibAdr,port,chVect,ampVect,dly);
    pause(0.2);
    
    chVect = [1,2,3,4];
    stVect = {'ON','ON','ON','ON'};
    
    fprintf(oscObj,'ACQuire:STATE ON');
    
    % Switch channel on
    outputStatusTTi_TGA1244(connType,gpibAdr,port,chVect,stVect,dly);
    pause(0.1);
    
    triggerTTi_TGA1244(connType,gpibAdr,port,dly);
    
    pause(1);
    fprintf(oscObj,'ACQuire:STATE off');
    
    % Switch channel off
    stVect = {'OFF','OFF','OFF','OFF'};
    outputStatusTTi_TGA1244(connType,gpibAdr,port,chVect,stVect,dly);

    
    % Retrieve data
    OscData = oscRetrieve(oscObj,oscch);
    
    % plot
    trace = OscData.Curve;
    t = OscData.Time;
    for j=1:numel(oscch)-1
        if j==1
            I = trace(1,:)/50;
            set(figure(1),'position',[100 100 560 820]);
            subplot(5,1,1);
            plot(t,I,'r');grid on;
            ylim([-120e-6 120e-6]);xlim([0 max(t)]);
            xlabel('Time - [s]');ylabel('Current - [A]');
        else
            v = trace(j,:);
            subplot(5,1,j);
            plot(t,v,'b');grid on;
            ylim([-0.6 0.6]);yticks([-0.6 -0.3 0 0.3 0.6]);xlim([0 max(t)]);
            xlabel('Time - [s]');ylabel('Voltage - [V]');
        end
    end
    set(gca,'fontsize',9,'fontweight','bold','gridAlpha',0.07,'minorgridAlpha',0.07);
    
    % save
    save(strcat(parentDir,'\',sprintf('IN%d)TRACE.mat',c)),'OscData');
    saveas(figure(1),strcat(parentDir,'\',sprintf('IN%d)TRACE.fig',c)));
    saveas(figure(1),strcat(parentDir,'\',sprintf('IN%d)TRACE.png',c)));
    close
    c %#ok<NOPTS>
    pause(1);
end
fclose(oscObj);