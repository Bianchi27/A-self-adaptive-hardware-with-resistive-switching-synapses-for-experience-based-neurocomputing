% THIS MATLAB FUNCTION IS USED FOR THE HARDWARE DESIGNED IN THE
% PAPER "A SELF-ADAPTIVE HARDWARE WITH RESISTIVE SWITCHING SYNAPSES FOR 
% EXPERIENCE-BASED NEUROCOMPUTING" by Stefano Bianchi, Irene Munoz Martin
% et al.

% SOME DETAILS ARE HIDDEN DUE TO NON-DISCLOSURE AGREEMENTS

function setWaveTTi_TGA1244(connType,gpibAdr,port,chVect,ampUnitVect,ampVect,waveVect,DCoffsetVect,ZloadVect,tsampleVect,...
    modeVect,trigSourceVect,trigPer,trigEdgeVect,trigOutVect,bstcntVect,FmodeVect,ppulseVect,pptVect,pseqVect,pswp,...
    ptoneVect,dly)

% ==================== Help ====================
% ***** Function for selecting and setting all the parameters for TTi  *****
%
% connType = ['GPIB' => 'gpibAdr'] or ['Prologix' => 'port']
% gpibAdr = Instrument address
% port = Communnication port in case of using Prologix 
%  $$$$$ All the vector of parameters should be entered in 1 to 1 correspondence of chVect $$$$$
% chVect = Vector of the channels e.g. [1 2 4] , [1 2 3 4] 
% ampUnitVect = set the amplitude mode for TTi
%            => for STD Wave : 'VPP', 'VRMS', 'DBM' 
%            => for ARB waveform only 'VPP' is avaliable and it will be set automatically
%            => e.g. {'VPP','VRMS'}, same size as chVect 
% ampVect = Vector of the amplitude values same size as chVect
% waveVect = a cell array of STD/ARB wave name, same size as chVect
%         => STD: 'SINE', 'SQUARE', 'TRIANG','DC', 'POSRMP', 'NEGRMP', 'COSINE','HAVSIN','HAVCOS', 'SINC', 'PULSE',
%                  'PULSTRN'
%         => ARB: An existing name of arbitrary wave
%         => 'SEQ' for sequence Mode
% DCoffsetVect = Vector of the DCoffset values same size as chVect e.g. [1 0.5 1]
% ZloadVect = a cell array of termination load 'OPEN','50','600' same size as chVect e.g. {'OPEN','50'}
% tsampleVect = Vector of the period values same size as chVect e.g. [500e-9 10e-6]
%
%                    =========== Mode ===========
% modeVect = a cell array of mode for channel same size as chVect: 'CONT', 'GATE', 'TRIG', 'SWEEP', 'TONE' 
%          => 'CONT': Continuous mode , no trigger source setup
%          => 'GATE': Gated mode, Level sensitive All avaliable trigger source (MAN is not suitable)
%                     Gate signal will be equall to 'ON' Time of the trigger source
%                     All avaliable trigger source can be set [the 'MAN' is not useful]
%                     Setup can be controlled in trigger input.
%          => 'TRIG': Edge sensitive All avaliable trigger source can be used + Burst Cont
%                     Edge sensitive, All avaliable trigger source can be set.
%         => 'SWEEP': Sweep mode, trigger source controlled by sweep parameter (only External Source)
%                      Max step = 2048 [All signals except Pulse/Puulse-train]
%          => 'TONE': Tone mode, Depends on the tone-type edge/level sensitive, All avaliable trigger source
%                     up to 16 dfferent user-specifed frequencies can be set.
%                     All avaliable trigger source can be set similar to above mentioned.
%
%                    =========== Trigger source ===========
% trigSoure = e.g.{'INT','PREV'}
%             'INT' for internal, 'EXT' for external, 'MAN' for manual, 'PREV' previous channel,
%             'NEXT' for next channel [Different for each channel same size as chVect]
%             
% trigPer = Internal trigger period [(Fixed for TGA1240] Limit : 10us-200s] [same
% for all channel] [Internal Trigger level can be set from -5 to 5 for TGA12102]
% trigEdgeVect = e.g. {'POS','NEG'} [Different for each channel same size as chVect]
% slope parameter for all sources => 'POS' {rising edge and positive level of trigger signal}
%                                    'NEG' {falling edge and negative level of trigger signal}
% trigOutVect = 'AUTO', 'WFMEND', 'POSNMKR', 'SEQSYNC' or 'BSTDONE'. [Different for each channel same size as chVect]
%               'WFMEND': Waveform end a positive−going pulse coincident with the end of a waveform cycle (and the 
%                start of the next).
%               'POSNMKR': Position marker; arbitrary waveforms only. Any point(s) on the main waveform may have marker
%                bit(s) set high or low. No output if selected for a standard waveform.
%               'SEQSYNC': Sequence sync; a positive−going pulse coincident with the end of a waveform sequence.
%               'BSTDONE': A positive−going pulse coincident with the end of the last cycle of a burst.
%
% bstcntVect = A vector of burst count same size as chVect in case of trigger/Burst Mode. [minimum is
%              1 and maximum is (2^20 -1)1048575] e.g. [1 20 30] max
% FmodeVect = a cell array of Filter mode of each channel same size chVect
%             for TGA1244:
%             'EL10': The automatic choice up to 10MHz for sine, cosine, haversine, havercosine, sinx/x and triangle. 
%                     Would be the better choice for arb waveforms with an essentially sinusoidal content
%             'EL16': The automatic choice above 10MHz for sine, cosine, haversine andhavercosine. Not recommended 
%                     for any other waveforms.
%             'BESS': The automatic choice for positive and negative ramps, arb and sequence.
%             'NONE': The automatic choice for squareware, pulse and pulse−trains. May be the better choice for arb
%                     waveforms with an essentially rectangular content.
%             for TGA12102:
%             'ELIP': The automatic choice for sine, cosine, haversine, havercosine, sinx/x and triangle. Would be 
%                     the better choice for arb waveforms with an essentially sinusoidal content.
%             'BESS': The automatic choice for positive and negative ramps, arb and sequence.
%             'NONE': The automatic choice for squarewave, pulse and pulse−trains. May be the better choice for arb
%                     waveforms with an essentially rectangular content.
%             for both Models:
%             'AUTO': set automatic mode
%
% ppulseVect = matrix of parameters for STD 'PULSE' matrix of vector of [PulsePeriod PulseWidth PulseDelay]
%            => number of row should be same as chVect
%
% pptVect = a struture fomred as followed for the STD 'PULSTRN'
%         => ppt.Len = number of pulses in pulse-train (Max 10)
%         => ppt.Per = total pulse period
%         => ppt.BL = baseline Voltage (rest Voltage)
%            % Matrix same size with total equal as pulse length %
%         => ppt.Num = Vector of pulse number
%         => ppt.Lvl = Vector of pulse Level
%         => ppt.Width = Vector of pulse Width
%         => ppt.Dly = Vector of Pulse delay
%
%                    =========== Sequence =========== 
% up to 16 arb wave can form a sequence (ONLY ARBITRARY)
% sequence can be considered as a wavetype which can be considered by waveVect.
% pseqVect = a structure array of the parameter for the sequence max array size should be similar to chVect
%          => pseq.num = Vector of sequence number position ,max size (1,16)
%          => pseq.count = Vector of number of repitition of the segment (Max 32768) ,max size (1,16)
%          => pseq.name = Vector of selected name ,max size (1,16)
%          => pseq.step = Vector of how to transient to next segement 'COUNT','TRGEDGE','TRGLEV'.
%                       => 'COUNT': when the number specified as the counter is reached move to new segment
%                       => 'TRGEDGE': Move to new segment at each trigger edge
%                       => 'TRGLEV': run continuously as long as the trigger level is ture ans stop
%                                    at latest segment and stay there wait for new true level to
%                                    continue from where it left. 
%                           [step on can be a combination of COUNT + EDGE or COUNT + LEVEL not EDGE
%                           + LEVEL] 
%             %Double input cell [Selected segment = '1' , status = 'ON' or 'OFF']%
%          => pseqstatus = pseq.status;
%                          If All segments are on:
%                          Switch off one in middle automatically switch off all subsequent segments
%                          Switch on segment in middle will automatically swich on all the
%                          segments between 1 and selected one.
%                          Seg one is always on
%
%                    =========== Sweep ===========
% pswp: Sweep parameters => pswp.num = [strfrq/centerfrq,stpfrq/span,Swp time,Swp markerfrq]
% Description: [start/center Frq , stop/span Frq ...
%               sweep time [0.03 - 999s] control number of steps, minimum dwell time (0.5ms) real STEP = (swptime/0.5e-3)
%               marker Frq]
%
% pswp: Sweep parameters => pswp.str = {range setup mode,Type,Swp direction,Syncstatus,spacing}
% if range setup mode = 'SF' => (start and final Frq as range]
%                     = 'CS' => (Center and span Frq as range]
% Type: 'CONT' for Continuous, 'MANUAL' for Manual, 'TRIG' for trigger, 'THLDRST' for trigger and
%        hold
% Swp direction : 'UP','DOWN', 'UPDN' for up-down, 'DNUP' for down-up
% sync status : 'ON' => the signal will be reset to zero frequency at end of sweep
%               'OFF' => the signal stays at ending frequency
% spacing : 'LIN' =>  Linear rate of frequecny change
%           'LOG' => stays for same amount time for each frequqncy decade
%
%                    =========== Tone ===========
% ptone: Tone parameters => ptone.Frq = [Vector of Frq]
%                        => ptone.Mode = [Tone mode : 1 'TRIG', 2 'FSK', any value 'GATED']
%% ==================== Check ====================
targetCh = sweepCheck(modeVect);
%% ==================== Main Code ====================
if strcmp(connType,'GPIB')
    g=gpib('ni',0,gpibAdr);
    g.Tag = 'TTiPort';
    g.InputBufferSize = 1.2e7;
    g.OutputBufferSize = 1.2e7;
    g.Timeout = 30;
    fopen(g);
    
    % Reset the Instrument
    fprintf(g, '*RST;');
    pause(dly);
    
    % Enable the OPC bit
    fprintf(g, '*OPC?');
    pause(dly);
    
    for i=1:numel(chVect)
        % ===== General Parameters =====
        % Channel
        ch = chVect(i);
        % Amplitude
        amp = ampVect(i);
        % DC Offset
        DCoffset = DCoffsetVect(i);
        % Sampling Period (distance between 2 points)
        tsample = tsampleVect(i);
        % Selected Wave
        wave = waveVect{i};
        % Output termination
        Zload = ZloadVect{i};
        % Filter
        Fmode = FmodeVect{i};
        
        % ===== Mode =====
        Mode  = modeVect{i};
        % One time sweep set
        if i==targetCh
            sweepFlag = true;
        else
            sweepFlag = false;
        end
        % Burst Count
        bstcnt = bstcntVect(i);
        
        % ===== Trigger Source Parameters =====
        % Trigger Source
        trigSource = trigSourceVect{i};
        % Trigger Edge
        trigEdge = trigEdgeVect{i};
        % Trigger Out
        if strcmp(trigSource,'PREV') || strcmp(trigSource,'NEXT')
            trigOut = trigOutVect{i};
        else
            trigOut = '';
        end
        
        
        % Select the channel
        % All paramerters ajustment will be appiled to selected channel
        fprintf(g,'SETUPCH %d;', ch);
        pause(dly);
        % Set the main output <ON>, <OFF>, <NORMAL> or <INVERT>.
        fprintf(g,'OUTPUT OFF;');
        pause(dly);
        % Set output termination load: OPEN, 600 or 50 ohm
        if strcmp(Zload, 'OPEN')
            fprintf(g,'ZLOAD OPEN;');
        else
            fprintf(g, 'ZLOAD %s;', Zload);
        end
        pause(dly);
        % Set DC offset
        fprintf(g,'DCOFFS %d;',DCoffset);
        pause(dly);
        % Set the Amplitude of the wave
        fprintf(g,'AMPL %d;', amp);
        pause(dly);
        % TTi 1240 has <ARB> while the TTi 12102 does not
        % ShapeTyp: <SINE>, <SQUARE>, <TRIANG>,<DC>, <POSRMP>, <NEGRMP>, <COSINE>,<HAVSIN>,<HAVCOS>, <SINC>, <PULSE>,
        % <PULSTRN>
        if ~(strcmp(wave,'SINE') || strcmp(wave,'COSINE') || strcmp(wave,'SQUARE') || strcmp(wave,'TRIANG') ...
                || strcmp(wave,'POSRMP') || strcmp(wave,'NEGRMP') || strcmp(wave,'HAVSIN') || strcmp(wave,'HAVCOS')...
                || strcmp(wave,'SINC') || strcmp(wave,'PULSE') || strcmp(wave,'PULSTRN') || strcmp(wave,'DC') || strcmp(wave,'SEQ'))
            % ==================== ARB Waveform ====================
            % TTi 1240 has <ARB> while the TTi 12102 does not for wave type
            % fprintf(g,'WAVE ARB;');
            % pause(dly);
            % Choose the ARB wave for the output
            fprintf(g,'ARB %s;', wave);
            pause(dly);
            % Set the CLK Period [CLKFREQ <nrf>;] can set Frq. (for ARB
            % wave)
            fprintf(g,'CLKPER %d;', tsample);
            pause(dly);
            fprintf(g,'*WAI');
        elseif strcmp(wave,'SEQ')
            % ==================== SEQ Waveform ====================
            pseq = pseqVect(i);
            seq(wave,pseq,tsample,dly);
        else
            % ==================== STD Waveform ====================
            % Amplitude Unit (not necessary for the DC)
            ampUnit = ampUnitVect{i};
            if strcmp(wave,'PULSE')
                ppulse = ppulseVect(i,:);
            else
                ppulse = [];
            end
            if strcmp(wave,'PULSTRN')
                ppt = pptVect(i);
            else
                ppt = [];
            end
            STDWave(wave,ampUnit,tsample,ppulse,ppt,dly);
        end
        % ==================== Mode selection ====================
        if strcmp(Mode,'TONE')
            ptone = ptoneVect(i);
        else
            ptone = [];
        end
        operationMode(Mode,trigSource,trigPer,trigEdge,ch,trigOut,bstcnt,pswp,sweepFlag,ptone,dly);
        fprintf(g,'*WAI');
        
        % Set Filter for each channel
        % Set the output filter to <AUTO>, <EL10>, <EL16>, <BESS> or <NONE>
        fprintf(g,'FILTER %s;',Fmode);
        pause(dly);
        
        % Wait to complete all operations
        status=query(g, '*OPC?');
        while(strfind(status,'1')~=1)
            status=query(g, '*OPC?');
        end
    end
    fclose(g);
    delete(g);
    clear g
elseif strcmp(connType,'Prologix')
    g=serial(port); 
    g.Tag = 'TTiPort';
    g.InputBufferSize = 1.2e7;
    g.OutputBufferSize = 1.2e7;
    g.Timeout = 30;
    g.Terminator = 'LF';
    fopen(g);
    
    % Prologix Control (++ is at start of all commands)
    % setting the mode of Prologix
    % Mode: (0 = Device),(1 = Controller)
    % Controller is used to control instrument
    fprintf(g,'++mode 1');
    % Set address of GPIB
    address=sprintf('++addr %d',gpibAdr);
    fprintf(g,address);
    pause(dly);
    % Enable EOI of Prologix
    fprintf(g,'++eoi 1');
    pause(dly);
    % Set read timeout Prologix
    fprintf(g,'++read_tmo_ms 50');
    pause(dly);
    
    % Reset the Instrument
    fprintf(g, '*RST;');
    pause(dly);
    
    % Enable the OPC bit
    fprintf(g, '*OPC');
    pause(dly);
    
    for i=1:numel(chVect)
        % ===== General Parameters =====
        % Channel
        ch = chVect(i);
        % Amplitude
        amp = ampVect(i);
        % DC Offset
        DCoffset = DCoffsetVect(i);
        % Sampling Period (distance between 2 points)
        tsample = tsampleVect(i);
        % Selected Wave
        wave = waveVect{i};
        % Output termination
        Zload = ZloadVect{i};
        % Filter
        Fmode = FmodeVect{i};
        
        
        % ===== Mode =====
        Mode  = modeVect{i};
        % One time sweep set
        if i==targetCh
            sweepFlag = true;
        else
            sweepFlag = false;
        end
        % Burst Count
        bstcnt = bstcntVect(i);
        
        % ===== Trigger Source Parameters =====
        % Trigger Source
        trigSource = trigSourceVect{i};
        % Trigger Edge
        trigEdge = trigEdgeVect{i};
        % Trigger Out
        if strcmp(trigSource,'PREV') || strcmp(trigSource,'NEXT')
            trigOut = trigOutVect{i};
        else
            trigOut = '';
        end
        
        
        % Select the channel
        % All paramerters ajustment will be appiled to selected channel
        fprintf(g,'SETUPCH %d;', ch);
        pause(dly);
        % Set the main output <ON>, <OFF>, <NORMAL> or <INVERT>.
        fprintf(g,'OUTPUT OFF;');
        pause(dly);
        % Set output termination load: OPEN, 600 or 50 ohm
        if strcmp(Zload, 'OPEN')
            fprintf(g,'ZLOAD OPEN;');
        else
            fprintf(g, 'ZLOAD %s;', Zload);
        end
        pause(dly);
        % Set DC offset
        fprintf(g,'DCOFFS %d;',DCoffset);
        pause(dly);
        % Set the Amplitude of the wave
        fprintf(g,'AMPL %d;', amp);
        pause(dly);
        % TTi 1240 has <ARB> while the TTi 12102 does not
        % ShapeTyp: <SINE>, <SQUARE>, <TRIANG>,<DC>, <POSRMP>, <NEGRMP>, <COSINE>,<HAVSIN>,<HAVCOS>, <SINC>, <PULSE>,
        % <PULSTRN>
        if ~(strcmp(wave,'SINE') || strcmp(wave,'COSINE') || strcmp(wave,'SQUARE') || strcmp(wave,'TRIANG') ...
                || strcmp(wave,'POSRMP') || strcmp(wave,'NEGRMP') || strcmp(wave,'HAVSIN') || strcmp(wave,'HAVCOS')...
                || strcmp(wave,'SINC') || strcmp(wave,'PULSE') || strcmp(wave,'PULSTRN') || strcmp(wave,'DC') || strcmp(wave,'SEQ'))
            % ==================== ARB Waveform ====================
            % TTi 1240 has <ARB> while the TTi 12102 does not for wave type
            % fprintf(g,'WAVE ARB;');
            % pause(dly);
            % Choose the ARB wave for the output
            fprintf(g,'ARB %s;', wave);
            pause(dly);
            % Set the CLK Period [CLKFREQ <nrf>;] can set Frq. (for ARB
            % wave)
            fprintf(g,'CLKPER %d;', tsample);
            pause(dly);
            fprintf(g,'*WAI');
        elseif strcmp(wave,'SEQ')
            % ==================== SEQ Waveform ====================
            pseq = pseqVect(i);
            seq(wave,pseq,tsample,dly);
        else
            % ==================== STD Waveform ====================
            % Amplitude Unit (not necessary for the DC)
            ampUnit = ampUnitVect{i};
            if strcmp(wave,'PULSE')
                ppulse = ppulseVect(i,:);
            else
                ppulse = [];
            end
            if strcmp(wave,'PULSTRN')
                ppt = pptVect(i);
            else
                ppt = [];
            end
            STDWave(wave,ampUnit,tsample,ppulse,ppt,dly);
        end
        % ==================== Mode selection ====================
        if strcmp(Mode,'TONE')
            ptone = ptoneVect(i);
        else
            ptone = [];
        end
        operationMode(Mode,trigSource,trigPer,trigEdge,ch,trigOut,bstcnt,pswp,sweepFlag,ptone,dly);
        fprintf(g,'*WAI');
        
        % Set Filter for each channel
        % Set the output filter to <AUTO>, <EL10>, <EL16>, <BESS> or <NONE>
        fprintf(g,'FILTER %s;',Fmode);
        pause(dly);
        tic
        % Query to wait for finishing all operation
        queryPrologix(dly);
        toc
    end
    fclose(g);
    delete(g);
    clear g
end
end
%% ==================== Local Function ====================

% ******************** STD Function ********************
function STDWave(wave,ampUnit,tsample,ppulse,ppt,dly)
% Connecting to the port
g = instrfind('Tag','TTiPort');

% Set the Wave
fprintf(g,'WAVE %s;', wave);
pause(dly);
% Select the amplitude type: VPP(peak to peak),VRMS,DBM Except for DC
fprintf(g,'AMPUNIT %s;',ampUnit);
pause(dly);
% Set the Wave Period [CLKFREQ <nrf>;] can set Frq. (for ARB
% wave)
fprintf(g,'WAVPER %d;', tsample);
pause(dly);
% Only Pulse and Pulse-Train
switch wave
    case 'PULSE'
        % Set the period of pulse
        fprintf(g,'PULSPER %d;', ppulse(1));
        pause(dly);
        % Set the width of pulse
        fprintf(g,'PULSWID %d;', ppulse(2));
        pause(dly);
        % Set the delay of pulse
        fprintf(g,'PULSDLY %d;', ppulse(3));
        pause(dly);
    case 'PULSTRN'
        % ppt: Parameter of Pulse-Train structure
        if isstruct(ppt)
            pulseLen = ppt.Len;
            pulsePer = ppt.Per;
            pulseBL = ppt.BL;
            % Matrix same size with total equal as pulse length
            pulseNum = ppt.Num;
            pulseLvl = ppt.Lvl;
            pulseWidth = ppt.Width;
            pulseDly = ppt.Dly;
            % Set the pulse-train pulse number
            fprintf(g,'PULTRNLEN %d;', pulseLen);
            pause(dly);
            % Set the period of pulse-train pulse (s)
            fprintf(g,'PULTRNPER %d;', pulsePer);
            pause(dly);
            % Set the baseline of pulse-train pulse (V)
            fprintf(g,'PULTRNBASE %d;', pulseBL);
            pause(dly);
            for j=1:pulseLen
                % Set the level of pulse−train pulse number <nrf1> to <nrf2> Volts
                string = sprintf('PULTRNLEV %d,%d;', pulseNum(j),pulseLvl(j));
                fprintf(g,string);
                pause(dly);
                % Set the width of pulse−train pulse number <nrf1> to <nrf2> sec
                string = sprintf('PULTRNWID %d,%d;', pulseNum(j),pulseWidth(j));
                fprintf(g,string);
                pause(dly);
                % Set the delay of pulse−train pulse number <nrf1> to <nrf2> sec.
                string = sprintf('PULTRNDLY %d,%d;', pulseNum(j),pulseDly(j));
                fprintf(g,string);
                pause(dly);
            end
            % Makes the pulse−train and runs it
            fprintf(g,'PULTRNMAKE;');
            pause(dly);
        else
            error('Please provide a structur as an input');
        end
end
fprintf(g,'*WAI');
end

% ******************** Mode Function ********************
function operationMode(Mode,trigSource,trigPer,trigEdge,ch,trigOut,bstcnt,pswp,sweepFlag,ptone,dly)
%                    =========== Help ===========
% Function can setup All the modes of TTi Pulse generator (TGA1240,TGA12102)
%
%                    =========== Mode ===========
% Mode : % 'CONT', 'GATE', 'TRIG', 'SWEEP', 'TONE'
% CONT : Continuous mode , no trigger source setup
% GATE : Gated mode, Level sensitive All avaliable trigger source (MAN is not suitable)
% TRIG : Edge sensitive All avaliable trigger source can be used + Burst Cont
% SWEEP : Sweep mode, trigger source controlled by sweep parameter (only External Source)
% TONE : Tone mode, Depends on the tone-type edge/level sensitive, All avaliable trigger source
%
%                    =========== Gated ===========
% Gate signal will be equall to 'ON' Time of the trigger source
% All avaliable trigger source can be set [the 'MAN' is not useful]
% Setup can be controlled in trigger input
%
%                    =========== Trigger/Burst ===========
% Edge sensitive, All avaliable trigger source can be set
% bstcnt : Burst count [unique value for each channel]
%
%                    =========== Sweep ===========
% Max step = 2048 [All signals except Pulse/Puulse-train]
% pswp: Sweep parameters => pswp.num = [strfrq/centerfrq,stpfrq/span,Swp time,Swp markerfrq]
% Description: [start/center Frq , stop/span Frq ...
%               sweep time [0.03 - 999s] control number of steps, minimum dwell time (0.5ms) real STEP = (swptime/0.5e-3)
%               marker Frq]
%
% pswp: Sweep parameters => pswp.str = {range setup mode,Type,Swp direction,Syncstatus,spacing}
% if range setup mode = 'SF' => (start and final Frq as range]
%                     = 'CS' => (Center and span Frq as range]
% Type: 'CONT' for Continuous, 'MANUAL' for Manual, 'TRIG' for trigger, 'THLDRST' for trigger and
% hold
% Swp direction : 'UP','DOWN', 'UPDN' for up-down, 'DNUP' for down-up
% sync status : 'ON' => the signal will be reset to zero frequency at end of sweep
%               'OFF' => the signal stays at ending frequency
% spacing : 'LIN' =>  Linear rate of frequecny change
%           'LOG' => stays for same amount time for each frequqncy decade
%
%                    =========== Tone ===========
% up to 16 dfferent user-specifed frequencies can be set.
% All avaliable trigger source can be set similar to above mentioned
% ptone: Tone parameters => ptone.Frq = [Vector of Frq]
%                        => ptone.Mode = [Tone mode : 1 'TRIG', 2 'FSK', any value 'GATED']

% Connecting to the port
g = instrfind('Tag','TTiPort');

switch Mode
    case 'CONT'
        % Set the Mode
        fprintf(g,'MODE %s;',Mode);
        pause(dly);
    case 'GATE'
        % Set the Mode
        fprintf(g,'MODE %s;',Mode);
        pause(dly);
        
        % ===== Gated Prameter =====
        % set Gate signal by setting trigger source parameter
        % Tigger source => 'INT', 'EXT', 'PREV', 'NEXT' ['MAN' is not useful']
        trigger(trigSource,trigPer,trigEdge,ch,trigOut,dly);
    case 'TRIG'
        % Set the Mode
        fprintf(g,'MODE %s;',Mode);
        pause(dly);
        % ===== Trigger/Burst Prameter =====
        % Set the burst count value (Only for Trigger Mode)
        % witch each treigger pulse, bstcnt pulse will be generated
        % Limit : (2^20 - 1) = 1048575
        fprintf(g,'BSTCNT %d;',bstcnt);
        pause(dly);
        
        % ===== Trigger source =====
        % Tigger source => 'INT', 'EXT', 'PREV', 'NEXT', 'MAN'
        trigger(trigSource,trigPer,trigEdge,ch,trigOut,dly);
    case 'SWEEP'
        % Set the Mode
        fprintf(g,'MODE %s;',Mode);
        pause(dly);
        
        % Since the sweep paramters are the same one time set is enough
        if sweepFlag
            % ===== Sweep Prameter =====
            % TTi 1240;
            % sweep mode has pre-defined of 2048 steps between start and stop.
            % the durtioan of the process can be set with SWPTIME.
            % if the SWPDIR is up/down or vice verca, the time and steps
            % divides between back and fort sweep.
            
            % psweep.num : [strfrq/centerfrq stpfrq/span swtime swmarkerfrq]
            % psweep.str : [SandF sweeptype]
            if isstruct(pswp)
                pswpnum = pswp.num;
                pswpstr = pswp.str;
                % ==== Range Menu =====
                % SandF : start/finish (SF) or center/span (CS)
                SandF = pswpstr{1};
                if strcmp(SandF,'SF')
                    % Set the sweep start frequency to <nrf> Hz
                    fprintf(g,'SWPSTARTFRQ %d;',pswpnum(1));
                    pause(dly);
                    % Set the sweep stop frequency to <nrf> Hz
                    fprintf(g,'SWPSTOPFRQ %d;',pswpnum(2));
                    pause(dly);
                elseif strcmp(SandF,'CS')
                    % Set the sweep centre frequency to <nrf> Hz
                    fprintf(g,'SWPCENTFRQ %d;',pswpnum(1));
                    pause(dly);
                    % Set the sweep frequency span to <nrf> Hz
                    fprintf(g,'SWPSPAN %d;',pswpnum(2));
                    pause(dly);
                end
                
                % ==== Type Menu =====
                % Set the sweep type to <CONT>, <TRIG>, <THLDRST> or <MANUAL>
                % <TRIG>, <THLDRST> Trigger fixed to External Source
                % <CONT> Does not need trigger setup
                fprintf(g,'SWPTYPE %s;',pswpstr{2});
                pause(dly);
                
                % ***** Manual Mode Setting *****
                % Control outsie this function
                
                % Set the sweep direction to <UP>, <DOWN>, <UPDN> or <DNUP>
                fprintf(g,'SWPDIRN %s;',pswpstr{3});
                pause(dly);
                % Set the sweep sync <ON> or <OFF>
                % Sync ON: Wave Frq goes to Zero(DC) at end of the Sweep
                % sync Off: Wave Frq goes to starting value instead of Zero (DC)
                fprintf(g,'SWPSYNC %s;',pswpstr{4});
                pause(dly);
                
                % ==== Time Menu =====
                % Set the sweep time to <nrf> sec
                % Limit :  0.03 to 999 s
                fprintf(g,'SWPTIME %f;',pswpnum(3));
                pause(dly);
                
                % ==== Spacing Menu =====
                % Set the sweep spacing to <LIN> or <LOG>
                fprintf(g,'SWPSPACING %s;',pswpstr{5});
                pause(dly);
                
                % ==== Marker Menu =====
                % Set the sweep marker to <nrf> Hz
                % it should be in the input range
                fprintf(g,'SWPMKR %d;',pswpnum(4));
                pause(dly);
                
                fprintf(g,'*WAI');
            else
                error('Please provide a structur as an input');
            end
        end
    case 'TONE'
        % Set the Mode
        fprintf(g,'MODE %s;',Mode);
        pause(dly);
        
        if isstruct(ptone)
            % ==== Tone Parameters =====
            % Limit: 16 Frequencies
            frqVect = ptone.Frq;
            toneType = ptone.Mode;
            for i=1:numel(frqVect)
                % Set tone frequency number <nrf1> to <nrf2> Hz. The third
                % parameter sets the tone type; 1 will give Trig, 2 will give FSK,
                % any other value gives Gate type.
                string = sprintf('TONEFREQ %d,%d,%d;',i,frqVect(i),toneType);
                fprintf(g,string);
                pause(dly);
                % Delete tone frequency number <nrf> thus defining the end of the list.
                % fprintf(g,'TONEEND %d;',ptone(4));
                % pause(dly);
            end
            
            % ===== Trigger source =====
            % Tigger source => 'INT', 'EXT', 'PREV', 'NEXT', 'MAN'
            trigger(trigSource,trigPer,trigEdge,ch,trigOut,dly);
            
            fprintf(g,'*WAI');
        else
            error('Please provide a structur as an input');
        end
end
end

% ******************** Sweep check Function ********************
function targetCh = sweepCheck(modeVect)
% ===== Help =====
% make sure that only with the first channel applies all the parameter and only once

% Temperory Variable
temp = NaN(1,numel(modeVect));

for i=1:numel(modeVect)
    if strcmp(modeVect{i},'SWEEP')
        temp(i) = i;
    end
end
targetCh = min(temp,[],'omitnan');
end

% ******************** Trigger Function ********************
function trigger(trigSource,trigPer,trigEdge,ch,trigOut,dly)
% Connecting to the port
g = instrfind('Tag','TTiPort');

% ==== Trigger source =====
% Set the trigger source
% Set the trig input to <INT>, <EXT>, <MAN>, <PREV>, <NEXT>
fprintf(g,'TRIGIN %s;',trigSource);
pause(dly);

switch trigSource
    case 'INT'
        % Trigger level = 5V (Fixed for TTi TGA1240]
        % Limit : 10us-200s , [5m-100k Hz] with duty cycle of 50%
        % Set trigger period
        fprintf(g,'TRIGPER %d;',trigPer);
        pause(dly);
        % TRIG is edge sensitive: <POS> {rising edge and positive level of trigger signal}
        %                         <NEG> {falling edge and negative level of trigger signal}
        fprintf(g,'TRIGIN %s;',trigEdge);
        pause(dly);
    case 'PREV'
        % Set previous Channel
        if ch==1
            chp = 4;
        else
            chp = ch -1;
        end
        
        % Select the Previous channel
        % All paramerters ajustment will be appiled to selected channel
        fprintf(g,'SETUPCH %d;', chp);
        pause(dly);
        
        % ===== TriggerOut =====
        % Set the trig output to <AUTO>, <WFMEND>, <POSNMKR>, <SEQSYNC> or <BSTDONE>
        fprintf(g,'TRIGOUT %s;', trigOut);
        pause(dly);
        
        % Select the current channel
        % All paramerters ajustment will be appiled to selected channel
        fprintf(g,'SETUPCH %d;', ch);
        pause(dly);
    case 'NEXT'
        % Set previous Channel
        if ch==4
            chn = 1;
        else
            chn = ch + 1;
        end
        
        % Select the Previous channel
        % All paramerters ajustment will be appiled to selected channel
        fprintf(g,'SETUPCH %d;', chn);
        pause(dly);
        
        % ===== TriggerOut =====
        % Set the trig output to <AUTO>, <WFMEND>, <POSNMKR>, <SEQSYNC> or <BSTDONE>
        fprintf(g,'TRIGOUT %s;', trigOut);
        pause(dly);
        
        % Select the current channel
        % All paramerters ajustment will be appiled to selected channel
        fprintf(g,'SETUPCH %d;', ch);
        pause(dly);
    otherwise
        % TRIG is edge sensitive: <POS> {rising edge and positive level of trigger signal}
        %                         <NEG> {falling edge and negative level of trigger signal}
        fprintf(g,'TRIGIN %s;',trigEdge);
        pause(dly);
end
end

% ******************** Sequence Function ********************
function seq(wave,pseq,tsample,dly)
% Connecting to the port
g = instrfind('Tag','TTiPort');

% Set the Wave
fprintf(g,'WAVE %s;', wave);
pause(dly);

% Set the CLK Period [CLKFREQ <nrf>;] can set Frq. (for ARB wave)
fprintf(g,'CLKPER %d;', tsample);
pause(dly);

% up to 16 arb wave can form a sequence
if isstruct(pseq)
    % All the matrix should have same size
    pseqnum = pseq.num;
    pseqcount = pseq.count;
    pseqname = pseq.name;
    pseqstep = pseq.step;
    %Double input cell [Selected channel , status]
    pseqstatus = pseq.status;
    % pseqnum = [sequence segment, sequence count]
    % pseqstr = {existing arbitrary waveform name, Step on,status}
    % step on can be a combination of COUNT + EDGE or COUNT + LEVEL
    % not EDGE + LEVEL
    for i=1:numel(pseqnum)
        % Set the 'waveform' parameter for sequence segment <nrf> to <cpd>,
        % <cpd> must be the name of an existing arbitrary waveform
        string = sprintf('SEQWFM %d,%s;', pseqnum(i),pseqname{i});
        fprintf(g,string);
        pause(dly);
        % Set the 'step on' parameter for sequence segment <nrf> to <COUNT>,
        % <TRGEDGE> or <TRGLEV>.
        string = sprintf('SEQSTEP %d,%s;', pseqnum(i),pseqstep{i});
        fprintf(g,string);
        pause(dly);
        % Set count for sequence segment <nrf1> to <nrf2> max= 32768
        string = sprintf('SEQCNT %d,%d;', pseqnum(i),pseqcount(i));
        fprintf(g,string);
        pause(dly);
    end
    % If All segments are on:
    % Switch off one in middle automatically switch off all subsequent segments
    % Switch on somtting in middle will automatically swich on all the
    % segments between 1 and selected one.
    % Seg one is always on
    % Set the status of sequence segment <nrf> to <ON> or <OFF>
    % Except segment [1]
    string = sprintf('SEQSEG %d,%s;', pseqnum(str2double(pseqstatus{1})),pseqstatus{2});
    fprintf(g,string);
    pause(dly);
else
    error('Please provide a structur as an input');
end
end

% ******************** Query Function ********************
function queryPrologix(dly)
% Connecting to the port
g = instrfind('Tag','TTiPort');

% OPC Bit: 1 if all operation have been finished otherwise 0
fprintf(g, '*OPC?');
fprintf(g,'++read eoi');
readasync(g);
pause(dly);
if g.BytesAvailable ~=0
    status = fscanf(g);
    TF = contains(status,'1');
else
    TF = false;
end
while(~TF)
    % Transfer status of port
    TSF = g.TransferStatus;
    % make sure that only one read command is available
    if strcmp(TSF,'idle')
        fprintf(g,'++read eoi');
        readasync(g);
        if g.BytesAvailable ~=0 && strcmp(g.TransferStatus,'idle')
            status = fscanf(g);
            TF = contains(status,'1'); % index flag
        end
    end
end
% Clearing the input buffer and stop reading
flushinput(g);
end
