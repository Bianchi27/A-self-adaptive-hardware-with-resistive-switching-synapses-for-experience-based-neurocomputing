% THIS MATLAB FUNCTION IS USED FOR THE HARDWARE DESIGNED IN THE
% PAPER "A SELF-ADAPTIVE HARDWARE WITH RESISTIVE SWITCHING SYNAPSES FOR 
% EXPERIENCE-BASED NEUROCOMPUTING" by Stefano Bianchi, Irene Munoz Martin
% et al.

% SOME DETAILS ARE HIDDEN DUE TO NON-DISCLOSURE AGREEMENTS

function loadWaveTTi_TGA1244(connType,gpibAdr,port,waveStr,waveNameVect,dly)
% ==================== Help ====================
% ***** Function for loading ARB WAVE to TTi *****
%
% connType = ['GPIB' => 'gpibAdr'] or ['Prologix' => 'port']
% gpibAdr port: GPIB address and Serial port for Prologix
% BOTH VECTORS SHOULD BE SAME SIZE:
% waveStr = structur consist of all the waves to be loaded into TTi 
%           the structure should have single fields with any name
%           size of the wave can be different 
% waveName = {'IN1', ... } a cell array of desired size, conisist of string up to 8 Char as a name 
% 
% TTi limits: Hor. 8-1e6 points per channel , Ver. 12 bits (4096 Level)
% dly = delay time betwwen each instruction

%% ==================== Main Code ====================
full_scale = (2^12); % Ver scale is 12 bit DAC (-2048,2047)

if strcmp(connType,'GPIB')
    g=gpib('ni',0,gpibAdr);
    g.InputBufferSize = 1.2e7;
    g.OutputBufferSize = 1.2e7;
    g.Timeout = 30;
    fopen(g);
    
    % Reset the Instrument
    fprintf(g, '*RST;');
    pause(dly);
    
    % Field name
    fn = char(fieldnames(waveStr));
    for i=1:numel(waveNameVect)
        % ===== Creat Wave =====
        clear wave waveString waveName
        wave = waveStr(i).(fn);
        waveName = waveNameVect{i};
        % Normalization of Wave and conversion to Level
        [abs_max,~] = max(abs(wave));
        
        if max(wave)== abs_max
            wave = wave/abs_max*(full_scale/2-1); % Positive
        else
            wave = wave/abs_max*full_scale/2; % Negative
        end
        % Wave
        wave  = round(wave);
        
        % Convert wave to string
        waveString = sprintf('%d,',wave(:));
        % Wave name, Hor. Length, and Wave
        string = sprintf('ARBDEFCSV %s,%d,%s;', waveName, length(wave), waveString);
        fprintf(g,string);
        pause(dly);
        
        % Wait for all overlapped operation to be finished
        fprintf(g, '*WAI;');
        pause(dly)
        
        % Wait to complete all operations
        status=query(g, '*OPC?');
        while(strfind(status,'1')~=1)
            status=query(g, '*OPC?');
        end
    end
    fclose(g);
    delete(g);
    clear g
elseif strcmp(connType,'Prologix')
    g=serial(port);
    g.Tag = 'TTiPort';
    g.InputBufferSize = 1.2e7;
    g.OutputBufferSize = 1.2e7;
    g.Timeout = 30;
    g.Terminator = 'LF';
    fopen(g);
    
    % Prologix Control (++ is at start of all commands)
    % setting the mode of Prologix
    % Mode: (0 = Device),(1 = Controller)
    % Controller is used to control instrument
    fprintf(g,'++mode 1');
    % Set address of GPIB
    address=sprintf('++addr %d',gpibAdr);
    fprintf(g,address);
    pause(dly);
    % Enable EOI of Prologix
    fprintf(g,'++eoi 1');
    pause(dly);
    % Set read timeout Prologix
    fprintf(g,'++read_tmo_ms 50');
    pause(dly);
    
    % Reset the Instrument
    fprintf(g, '*RST;');
    pause(dly);
    
    % Enable the OPC bit
    fprintf(g, '*OPC');
    pause(dly);
    
    % Field name
    fn = char(fieldnames(waveStr));
    for i=1:numel(waveNameVect)
        % ===== Creat Wave =====
        clear wave waveString waveName
        wave = waveStr(i).(fn);
        waveName = waveNameVect{i};
        % Normalization of Wave and conversion to Level
        [abs_max,~] = max(abs(wave));
        
        if max(wave)== abs_max
            wave = wave/abs_max*(full_scale/2-1); % Positive
        else
            wave = wave/abs_max*full_scale/2; % Negative
        end
        % Wave
        wave  = round(wave);
        
        % Convert wave to string
        waveString = sprintf('%d,',wave(:));
        % Wave name, Hor. Length, and Wave
        string = sprintf('ARBDEFCSV %s,%d,%s;', waveName, length(wave), waveString);
        fprintf(g,string);
        pause(dly);
        
        % Wait for all overlapped operation to be finished
        fprintf(g, '*WAI;');
        pause(dly)
        
        tic
        % Query to wait for finishing all operation
        queryPrologix(dly);
        toc
    end
    fclose(g);
    delete(g);
    clear g
end
end

%% ==================== Local Function ====================

% ******************** Query Function ********************
function queryPrologix(dly)
% Connecting to the port
g = instrfind('Tag','TTiPort');

% OPC Bit: 1 if all operation have been finished otherwise 0
fprintf(g, '*OPC?');
fprintf(g,'++read eoi');
readasync(g);
pause(dly);
if g.BytesAvailable ~=0
    status = fscanf(g);
    TF = contains(status,'1');
else
    TF = false;
end
while(~TF)
    % Transfer status of port
    TSF = g.TransferStatus;
    % make sure that only one read command is available
    if strcmp(TSF,'idle')
        fprintf(g,'++read eoi');
        readasync(g);
        if g.BytesAvailable ~=0 && strcmp(g.TransferStatus,'idle')
            status = fscanf(g);
            TF = contains(status,'1'); % index flag
        end
    end
end
% Clearing the input buffer and stop reading
flushinput(g);
end