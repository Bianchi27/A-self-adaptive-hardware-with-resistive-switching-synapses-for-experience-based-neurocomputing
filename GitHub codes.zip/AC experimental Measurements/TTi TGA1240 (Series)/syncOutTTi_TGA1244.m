% THIS MATLAB FUNCTION IS USED FOR THE HARDWARE DESIGNED IN THE
% PAPER "A SELF-ADAPTIVE HARDWARE WITH RESISTIVE SWITCHING SYNAPSES FOR 
% EXPERIENCE-BASED NEUROCOMPUTING" by Stefano Bianchi, Irene Munoz Martin
% et al.

% SOME DETAILS ARE HIDDEN DUE TO NON-DISCLOSURE AGREEMENTS

function syncOutTTi_TGA1244(connType,gpibAdr,port,chVect,syncStVect,syncModeVect,dly)
% ==================== Help ====================
% ***** Function for setting Syncout  *****
%
% connType = ['GPIB' => 'gpibAdr'] or ['Prologix' => 'port']
% gpibAdr = Instrument address
% port = Communnication port in case of using Prologix 
% chVect = Vector of the channels e.g. [1 2 4] , [1 2 3 4]
% syncStVect: 'ON', 'OFF' same size as chVect
% syncModeVect: 'WFMSYNC', 'POSNMKR', 'BSTDONE', 'SEQSYNC', 'TRIGGER', 'SWPTRG' or 'PHASLOC'
%               'WFMSYNC' => A square wave with 50% duty cycle at the main waveform frequency, or a pulse coincident
%                with the first few points of an arbitrary waveform. Can be selected for all waveforms.
%               'POSNMKR' => Can be selected for arbitrary waveforms only. Any point(s) on the main waveform may have
%                associated marker bit(s) set high or low. When the MAIN OUT waveform is a standard waveform position 
%                marker is not available and this choice on the list automatically becomes phase zero; if selected, 
%                phase zero produces a narrow (1 clock) pulse at the start of each standard waveform cycle.
%               'BSTDONE' => Produces a pulse coincident with the last cycle of the burst.
%               'SEQSYNC' => Produces a pulse coincident with the end of a waveform sequence.
%               'TRIGGER' => Selects the current trigger signal (internal, external, adjacent channel or manual).
%                Useful for synchronising burst or gated signals.
%               'SWPTRG' => Outputs the sweep trigger signal. (@ end of sweep time)
%               'PHASLOC' => Used to lock two or more generators. Produces a positive edge at the 0º phase point.
%
% The 'AUTO' OR 'MAN'  mode will be set by setting the Output mode. ann the amplitude if the syncout:
% TGA1244 = 5V fixed 
% TGA12102 = 3.5V fixed
% dly = delay between sending each command 

%% ==================== Main Code ====================
if strcmp(connType,'GPIB')
    g=gpib('ni',0,gpibAdr);
    g.InputBufferSize = 1.2e7;
    g.OutputBufferSize = 1.2e7;
    g.Timeout = 30;
    fopen(g);
    
    for i=1:numel(chVect)
        % Channel
        ch = chVect(i);
        % Sync status
        syncSt = syncStVect{i};
        
        % Select the channel
        fprintf(g,'SETUPCH %d;',ch);
        pause(dly);
        % Sync status: ON OR OFF
        fprintf(g,'SYNCOUT %s;',syncSt);
        pause(dly);
        if strcmp(syncSt,'ON')
            syncMode = syncModeVect{i};
            % Select type of symc output
            fprintf(g,'SYNCOUT %s;',syncMode);
            pause(dly);
        end
        
        % Wait for all overlapped operation to be finished
        fprintf(g,'*WAI;');
        pause(dly);
    end
    fclose(g);
    delete(g);
    clear g
elseif strcmp(connType,'Prologix')
    g=serial(port);
    g.InputBufferSize = 1.2e7;
    g.OutputBufferSize = 1.2e7;
    g.Timeout = 30;
    g.Terminator = 'CR/LF';
    fopen(g);
    
    % Prologix Control (++ is at start of all commands)
    % setting the mode of Prologix
    % Mode: (0 = Device),(1 = Controller)
    % Controller is used to control instrument
    fprintf(g,'++mode 1');
    % Set address of GPIB
    address=sprintf('++addr %d',gpibAdr);
    fprintf(g,address);
    pause(dly);
    
    for i=1:numel(chVect)
        % Channel
        ch = chVect(i);
        % Sync status
        syncSt = syncStVect{i};
        
        % Select the channel
        fprintf(g,'SETUPCH %d;',ch);
        pause(dly);
        % Sync status: ON OR OFF
        fprintf(g,'SYNCOUT %s;',syncSt);
        pause(dly);
        if strcmp(syncSt,'ON')
            syncMode = syncModeVect{i};
            % Select type of symc output
            fprintf(g,'SYNCOUT %s;',syncMode);
            pause(dly);
        end
        
        % Wait for all overlapped operation to be finished
        fprintf(g,'*WAI;');
        pause(dly);
    end
    fclose(g);
    delete(g);
    clear g
end
end