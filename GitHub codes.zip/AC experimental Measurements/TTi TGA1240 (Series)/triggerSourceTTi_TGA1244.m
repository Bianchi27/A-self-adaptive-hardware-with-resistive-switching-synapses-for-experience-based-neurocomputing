% THIS MATLAB FUNCTION IS USED FOR THE HARDWARE DESIGNED IN THE
% PAPER "A SELF-ADAPTIVE HARDWARE WITH RESISTIVE SWITCHING SYNAPSES FOR 
% EXPERIENCE-BASED NEUROCOMPUTING" by Stefano Bianchi, Irene Munoz Martin
% et al.

% SOME DETAILS ARE HIDDEN DUE TO NON-DISCLOSURE AGREEMENTS

function triggerSourceTTi_TGA1244(connType,gpibAdr,port,chVect,trigSourceVect,trigPer,trigEdgeVect,trigOutVect,dly)
% ==================== Help ====================
% ***** Function for setting the Triger source *****
%
% connType = ['GPIB' => 'gpibAdr'] or ['Prologix' => 'port']
% gpibAdr = Instrument address
% port = Communnication port in case of using Prologix 
% chVect = Vector of the channels e.g. [1 2 4] , [1 2 3 4]
% trigSoure = e.g.{'INT','PREV'}
%             'INT' for internal, 'EXT' for external, 'MAN' for manual, 'PREV' previous channel,
%             'NEXT' for next channel [Different for each channel same size as chVect]
%             
% trigPer = Internal trigger period [Trigger level = 5V (Fixed for TGA1240] Limit : 10us-200s] [same
% for all channel]
% trigEdgeVect = e.g. {'POS','NEG'} [Different for each channel same size as chVect]
% slope parameter for all sources => 'POS' {rising edge and positive level of trigger signal}
%                                    'NEG' {falling edge and negative level of trigger signal}
% trigOutVect = 'AUTO', 'WFMEND', 'POSNMKR', 'SEQSYNC' or 'BSTDONE'. [Different for each channel same size as chVect]
%               'WFMEND': Waveform end a positive−going pulse coincident with the end of a waveform cycle (and the 
%                start of the next).
%               'POSNMKR': Position marker; arbitrary waveforms only. Any point(s) on the main waveform may have marker
%                bit(s) set high or low. No output if selected for a standard waveform.
%               'SEQSYNC': Sequence sync; a positive−going pulse coincident with the end of a waveform sequence.
%               'BSTDONE': A positive−going pulse coincident with the end of the last cycle of a burst.

%% ==================== Main Code ====================
if strcmp(connType,'GPIB')
    g=gpib('ni',0,gpibAdr);
    g.InputBufferSize = 1.2e7;
    g.OutputBufferSize = 1.2e7;
    g.Timeout = 30;
    fopen(g);
    
    for i=1:numel(chVect)
        % Channel
        ch = chVect(i);
        
        % ===== Trigger Source Parameters =====
        % Trigger Source
        trigSource = trigSourceVect{i};
        % Trigger Edge
        trigEdge = trigEdgeVect{i};
        % Trigger Out
        if strcmp(trigSource,'PREV') || strcmp(trigSource,'NEXT')
            trigOut = trigOutVect{i};
        else
            trigOut = '';
        end
        
        % Select the channel
        fprintf(g,'SETUPCH %d;',ch);
        pause(dly);
        
        % ==== Trigger source =====
        % Set the trigger source
        % Set the trig input to <INT>, <EXT>, <MAN>, <PREV>, <NEXT>
        fprintf(g,'TRIGIN %s;',trigSource);
        pause(dly);
        
        switch trigSource
            case 'INT'
                % Trigger level = 5V (Fixed for TTi TGA1240]
                % Limit : 10us-200s , [5m-100k Hz] with duty cycle of 50%
                % Set trigger period
                fprintf(g,'TRIGPER %d;',trigPer);
                pause(dly);
                % TRIG is edge sensitive: <POS> {rising edge and positive level of trigger signal}
                %                         <NEG> {falling edge and negative level of trigger signal}
                fprintf(g,'TRIGIN %s;',trigEdge);
                pause(dly);
            case 'PREV'
                % Set previous Channel
                if ch==1
                    chp = 4;
                else
                    chp = ch -1;
                end
                
                % Select the Previous channel
                % All paramerters ajustment will be appiled to selected channel
                fprintf(g,'SETUPCH %d;', chp);
                pause(dly);
                
                % ===== TriggerOut =====
                % Set the trig output to <AUTO>, <WFMEND>, <POSNMKR>, <SEQSYNC> or <BSTDONE>
                fprintf(g,'TRIGOUT %s;', trigOut);
                pause(dly);
                
                % Select the current channel
                % All paramerters ajustment will be appiled to selected channel
                fprintf(g,'SETUPCH %d;', ch);
                pause(dly);
            case 'NEXT'
                % Set previous Channel
                if ch==4
                    chn = 1;
                else
                    chn = ch + 1;
                end
                
                % Select the Previous channel
                % All paramerters ajustment will be appiled to selected channel
                fprintf(g,'SETUPCH %d;', chn);
                pause(dly);
                
                % ===== TriggerOut =====
                % Set the trig output to <AUTO>, <WFMEND>, <POSNMKR>, <SEQSYNC> or <BSTDONE>
                fprintf(g,'TRIGOUT %s;', trigOut);
                pause(dly);
                
                % Select the current channel
                % All paramerters ajustment will be appiled to selected channel
                fprintf(g,'SETUPCH %d;', ch);
                pause(dly);
            otherwise
                % TRIG is edge sensitive: <POS> {rising edge and positive level of trigger signal}
                %                         <NEG> {falling edge and negative level of trigger signal}
                fprintf(g,'TRIGIN %s;',trigEdge);
                pause(dly);
        end
        
        % Wait for all overlapped operation to be finished
        fprintf(g,'*WAI;');
        pause(dly);
    end
    fclose(g);
    delete(g);
    clear g
elseif strcmp(connType,'Prologix')
    g=serial(port); 
    g.InputBufferSize = 1.2e7;
    g.OutputBufferSize = 1.2e7;
    g.Timeout = 30;
    g.Terminator = 'CR/LF';
    fopen(g);
    
    % Prologix Control (++ is at start of all commands)
    % setting the mode of Prologix
    % Mode: (0 = Device),(1 = Controller)
    % Controller is used to control instrument
    fprintf(g,'++mode 1');
    % Set address of GPIB
    address=sprintf('++addr %d',gpibAdr);
    fprintf(g,address);
    pause(dly);
    
    for i=1:numel(chVect)
        % Channel
        ch = chVect(i);
        
        % ===== Trigger Source Parameters =====
        % Trigger Source
        trigSource = trigSourceVect{i};
        % Trigger Edge
        trigEdge = trigEdgeVect{i};
        % Trigger Out
        if strcmp(trigSource,'PREV') || strcmp(trigSource,'NEXT')
            trigOut = trigOutVect{i};
        else
            trigOut = '';
        end
        
        % Select the channel
        fprintf(g,'SETUPCH %d;',ch);
        pause(dly);
        
        % ==== Trigger source =====
        % Set the trigger source
        % Set the trig input to <INT>, <EXT>, <MAN>, <PREV>, <NEXT>
        fprintf(g,'TRIGIN %s;',trigSource);
        pause(dly);
        
        switch trigSource
            case 'INT'
                % Trigger level = 5V (Fixed for TTi TGA1240]
                % Limit : 10us-200s , [5m-100k Hz] with duty cycle of 50%
                % Set trigger period
                fprintf(g,'TRIGPER %d;',trigPer);
                pause(dly);
                % TRIG is edge sensitive: <POS> {rising edge and positive level of trigger signal}
                %                         <NEG> {falling edge and negative level of trigger signal}
                fprintf(g,'TRIGIN %s;',trigEdge);
                pause(dly);
            case 'PREV'
                % Set previous Channel
                if ch==1
                    chp = 4;
                else
                    chp = ch -1;
                end
                
                % Select the Previous channel
                % All paramerters ajustment will be appiled to selected channel
                fprintf(g,'SETUPCH %d;', chp);
                pause(dly);
                
                % ===== TriggerOut =====
                % Set the trig output to <AUTO>, <WFMEND>, <POSNMKR>, <SEQSYNC> or <BSTDONE>
                fprintf(g,'TRIGOUT %s;', trigOut);
                pause(dly);
                
                % Select the current channel
                % All paramerters ajustment will be appiled to selected channel
                fprintf(g,'SETUPCH %d;', ch);
                pause(dly);
            case 'NEXT'
                % Set previous Channel
                if ch==4
                    chn = 1;
                else
                    chn = ch + 1;
                end
                
                % Select the Previous channel
                % All paramerters ajustment will be appiled to selected channel
                fprintf(g,'SETUPCH %d;', chn);
                pause(dly);
                
                % ===== TriggerOut =====
                % Set the trig output to <AUTO>, <WFMEND>, <POSNMKR>, <SEQSYNC> or <BSTDONE>
                fprintf(g,'TRIGOUT %s;', trigOut);
                pause(dly);
                
                % Select the current channel
                % All paramerters ajustment will be appiled to selected channel
                fprintf(g,'SETUPCH %d;', ch);
                pause(dly);
            otherwise
                % TRIG is edge sensitive: <POS> {rising edge and positive level of trigger signal}
                %                         <NEG> {falling edge and negative level of trigger signal}
                fprintf(g,'TRIGIN %s;',trigEdge);
                pause(dly);
        end
        
        % Wait for all overlapped operation to be finished
        fprintf(g,'*WAI;');
        pause(dly);
    end
    fclose(g);
    delete(g);
    clear g
end
end
