% THIS MATLAB FUNCTION IS USED FOR THE HARDWARE DESIGNED IN THE
% PAPER "A SELF-ADAPTIVE HARDWARE WITH RESISTIVE SWITCHING SYNAPSES FOR 
% EXPERIENCE-BASED NEUROCOMPUTING" by Stefano Bianchi, Irene Munoz Martin
% et al.

% SOME DETAILS ARE HIDDEN DUE TO NON-DISCLOSURE AGREEMENTS

function sweepManualTTi_TGA1244(connType,gpibAdr,port,ch,stMode,stSpeed,wrpStatus,swpDir,dly)
%% ==================== Help ====================
% syncStVect: <ON>, <OFF>
% syncModeVect: <WFMSYNC>, <POSNMKR>, <BSTDONE>, <SEQSYNC>, <TRIGGER>, <SWPTRG> or <PHASLOC>
% The 'AUTO' OR 'MAN'  mode will be set by setting the Output mode.
%% ==================== Main Code ====================
if strcmp(connType,'GPIB')
    g=gpib('ni',0,gpibAdr);
    g.InputBufferSize = 1.2e7;
    g.OutputBufferSize = 1.2e7;
    g.Timeout = 30;
    fopen(g);
    % No setup s needed for trigger
    
    % Select the channel
    fprintf(g,'SETUPCH %d;',ch);
    pause(dly);
    if stMode
        % Step Speed: 'FAST' OR 'SLOW'
        fprintf(g,'SWPMANUAL %s;',stSpeed);
        pause(dly);
        % Wraps-Rounds: 'OFF' (ends at last frq of sweep) Or 'ON' repeat the starting frq
        fprintf(g,'SWPMANUAL %s;',wrpStatus);
        pause(dly);
    end
    % sweeping Up or down
    fprintf(g,'SWPMANUAL %s;',swpDir);
    pause(dly);
    
    % Wait for all overlapped operation to be finished
    fprintf(g,'*WAI;');
    pause(dly);
    
    fclose(g);
    delete(g);
    clear g
elseif strcmp(connType,'Prologix')
    g=serial(port);
    g.InputBufferSize = 1.2e7;
    g.OutputBufferSize = 1.2e7;
    g.Timeout = 30;
    g.Terminator = 'CR/LF';
    
    fopen(g);
    % Prologix Control (++ is at start of all commands)
    % setting the mode of Prologix
    % Mode: (0 = Device),(1 = Controller)
    % Controller is used to control instrument
    fprintf(g,'++mode 1');
    % Set address of GPIB
    address=sprintf('++addr %d',gpibAdr);
    fprintf(g,address);
    pause(dly);
    
    % Select the channel
    fprintf(g,'SETUPCH %d;',ch);
    pause(dly);
    if stMode
        % Step Speed: 'FAST' OR 'SLOW'
        fprintf(g,'SWPMANUAL %s;',stSpeed);
        pause(dly);
        % Wraps-Rounds: 'OFF' (ends at last frq of sweep) Or 'ON' repeat the starting frq
        fprintf(g,'SWPMANUAL %s;',wrpStatus);
        pause(dly);
    end
    % sweeping Up or down
    fprintf(g,'SWPMANUAL %s;',swpDir);
    pause(dly);
    
    % Wait for all overlapped operation to be finished
    fprintf(g,'*WAI;');
    pause(dly);
    
    fclose(g);
    delete(g);
    clear g
end
end