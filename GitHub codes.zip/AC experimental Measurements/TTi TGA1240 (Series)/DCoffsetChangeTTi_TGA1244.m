% THIS MATLAB FUNCTION IS USED FOR THE HARDWARE DESIGNED IN THE
% PAPER "A SELF-ADAPTIVE HARDWARE WITH RESISTIVE SWITCHING SYNAPSES FOR 
% EXPERIENCE-BASED NEUROCOMPUTING" by Stefano Bianchi, Irene Munoz Martin
% et al.

% SOME DETAILS ARE HIDDEN DUE TO NON-DISCLOSURE AGREEMENTS

function DCoffsetChangeTTi_TGA1244(connType,gpibAdr,port,chVect,DCoffsetVect,dly)
% ==================== Help ====================
% ***** Function for setting the DC offset *****
%
% connType = ['GPIB' => 'gpibAdr'] or ['Prologix' => 'port']
% gpibAdr = Instrument address
% port = Communnication port in case of using Prologix 
% chVect = Vector of the channels e.g. [1 2 4] , [1 2 3 4]
% DCoffsetVect = Vector of the DCoffset values same size as chVect
% dly = delay between sending each command 
% 

%% ==================== Main Code ====================
if strcmp(connType,'GPIB')
    g=gpib('ni',0,gpibAdr);
    g.InputBufferSize = 1.2e7;
    g.OutputBufferSize = 1.2e7;
    g.Timeout = 30;
    fopen(g);
    
    for i=1:numel(chVect)
        % Channel
        ch = chVect(i);
        % DC Offset
        DCoffset = DCoffsetVect(i);
        
        % Select the channel
        fprintf(g,'SETUPCH %d;',ch);
        pause(dly);
        % Set DC offset
        fprintf(g,'DCOFFS %d;',DCoffset);
        pause(dly);
        
        % Wait for all overlapped operation to be finished
        fprintf(g,'*WAI;');
        pause(dly);
    end
    fclose(g);
    delete(g);
    clear g
elseif strcmp(connType,'Prologix')
    g=serial(port); 
    g.InputBufferSize = 1.2e7;
    g.OutputBufferSize = 1.2e7;
    g.Timeout = 30;
    g.Terminator = 'CR/LF';
    fopen(g);
    
    % Prologix Control (++ is at start of all commands)
    % setting the mode of Prologix
    % Mode: (0 = Device),(1 = Controller)
    % Controller is used to control instrument
    fprintf(g,'++mode 1');
    % Set address of GPIB
    address=sprintf('++addr %d',gpibAdr);
    fprintf(g,address);
    pause(dly);
    
    for i=1:numel(chVect)
        % Channel
        ch = chVect(i);
        % DC Offset
        DCoffset = DCoffsetVect(i);
        
        % Select the channel
        fprintf(g,'SETUPCH %d;',ch);
        pause(dly);
        % Set DC offset
        fprintf(g,'DCOFFS %d;',DCoffset);
        pause(dly);
        
        % Wait for all overlapped operation to be finished
        fprintf(g,'*WAI;');
        pause(dly);
    end
    fclose(g); 
    delete(g);
    clear g
end
end
